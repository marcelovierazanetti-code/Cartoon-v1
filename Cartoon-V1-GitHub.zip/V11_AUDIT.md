# Cartoon V11.0 — revisão técnica

## Correções aplicadas
- Versão 11.0 / versionCode 21.
- AGP 8.10.1 + Gradle 8.11.1 + Java 17 + compileSdk/targetSdk 36.
- Workflow não aceita mais silenciosamente uma árvore antiga do projeto: se a raiz não for V11, procura somente ZIP V11.
- Validação pré-build do projeto e das APIs/modelos usados.
- Mantida a API ativa `@cf/meta/llama-3.1-8b-instruct-fast` para roteiro e JSON Mode.
- Mantido FLUX.2 Klein 4B com multipart e referências abaixo de 512x512.
- Tratamento de HTTP 3030/"output has been flagged" com tentativas progressivas sem reenviar a mesma combinação bloqueada.
- Roteiro exige exatamente 3/6/10 cenas; após três falhas, o app aborta antes de gerar imagens para não criar vídeo inconsistente.
- Extração e validação do JSON retornado pelo modelo.
- Narração continua sendo gerada por cena com Gemini 3.1 Flash TTS.
- Prévia continua usando VideoView do MP4 real.
- Hardware acceleration explicitamente habilitada para reduzir problemas de reprodução/Surface.
- Nome/logo continuam como marca-d'água no vídeo.
- Configuração criptografada no Android Keystore continua preservada, mantendo o alias anterior para não perder as chaves salvas ao atualizar.

## Auditoria local
- Chaves `{}` balanceadas.
- Parênteses `()` balanceados.
- ZIP validado com `unzip -t`.
- Não há `TextureView` no código.
- Não há referências antigas V10.2/V9.1 no código de runtime.

## Limitação
A compilação final depende do ambiente GitHub Actions com Android SDK/Gradle. O ambiente de revisão não possui Gradle/Android SDK instalados, portanto o APK final deve ser confirmado pelo workflow do GitHub.
