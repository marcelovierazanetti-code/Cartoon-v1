# Cartoon V12.0 — revisão técnica

## Correções aplicadas
- Versão 12.0 / versionCode 22.
- AGP 8.10.1 + Gradle 8.11.1 + Java 17 + compileSdk/targetSdk 36.
- Workflow não aceita mais silenciosamente uma árvore antiga do projeto: se a raiz não for V12, procura somente ZIP V12.
- Validação pré-build do projeto e das APIs/modelos usados.
- Mantida a API ativa `@cf/meta/llama-3.1-8b-instruct-fast` para roteiro e JSON Mode.
- Mantido FLUX.2 Klein 4B com multipart e referências abaixo de 512x512.
- Tratamento de HTTP 3030/"output has been flagged" com tentativas progressivas sem reenviar a mesma combinação bloqueada.
- Roteiro exige exatamente 3/6/10 cenas; após três falhas, o app aborta antes de gerar imagens para não criar vídeo inconsistente.
- Extração e validação do JSON retornado pelo modelo.
- Narração continua sendo gerada por cena com Gemini 3.1 Flash TTS.
- Prévia continua usando VideoView do MP4 real.
- Hardware acceleration explicitamente habilitada para reduzir problemas de reprodução/Surface.
- Nome/logo continuam como marca-d'água no vídeo.
- Configuração criptografada no Android Keystore continua preservada, mantendo o alias anterior para não perder as chaves salvas ao atualizar.

## Auditoria local
- Chaves `{}` balanceadas.
- Parênteses `()` balanceados.
- ZIP validado com `unzip -t`.
- Não há `TextureView` no código.
- Não há referências antigas V10.2/V9.1 no código de runtime.

## Limitação
A compilação final depende do ambiente GitHub Actions com Android SDK/Gradle. O ambiente de revisão não possui Gradle/Android SDK instalados, portanto o APK final deve ser confirmado pelo workflow do GitHub.


## Cartoon V12.0 — correções adicionais
- Prévia reconstruída com TextureView + MediaPlayer e Surface dedicada, sem background drawable no TextureView, evitando a falha Android `TextureView doesn't support displaying a background drawable`.
- A prévia usa o mesmo arquivo MP4 final que será salvo, em vez de uma renderização separada.
- Liberação explícita de MediaPlayer/Surface no ciclo de vida para evitar vazamentos e travamentos ao regenerar.
- Validação visual ficou menos propensa a falsos negativos: somente uma resposta explicitamente iniciada por `FAIL` rejeita a imagem.
- Fluxo de geração mantém tentativas de segurança para HTTP 3030 e não altera o roteiro original quando a recuperação ocorre.
- VersionCode 22 / versionName 12.0.

- Alias do Android Keystore mantido como `cartoon_v4_key` para preservar as configurações criptografadas salvas nas versões anteriores.
