package com.cartoon.v1

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.media.*
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var tempVideo: File? = null
    private var tempNarration: File? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun js(name: String, value: String) {
        web.post { web.evaluateJavascript("window.$name(${JSONObject.quote(value)})", null) }
    }

    inner class Bridge {
        @JavascriptInterface
        fun synthesizeGeminiNarration(text: String, key: String, voice: String, lang: String) {
            Thread {
                try {
                    val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent")
                    val conn = url.openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json")
                    conn.setRequestProperty("x-goog-api-key", key)
                    val req = JSONObject().apply {
                        put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
                        put("generationConfig", JSONObject().apply {
                            put("responseModalities", JSONArray().put("AUDIO"))
                            put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))))
                        })
                    }
                    conn.outputStream.use { it.write(req.toString().toByteArray()) }
                    val body = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
                    if (conn.responseCode !in 200..299) throw Exception(JSONObject(body).optJSONObject("error")?.optString("message") ?: "Erro Gemini TTS")
                    val inline = JSONObject(body).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData")
                    val raw = Base64.decode(inline.getString("data"), Base64.DEFAULT)
                    val wav = pcmToWav(raw, 24000, 1, 16)
                    val file = File(cacheDir, "narration_${System.currentTimeMillis()}.wav")
                    file.writeBytes(wav)
                    tempNarration = file
                    js("onNativeNarrationReady", Uri.fromFile(file).toString())
                } catch (e: Exception) { js("onNativeError", e.message ?: "Erro TTS") }
            }.start()
        }

        @JavascriptInterface
        fun generateGeminiImage(prompt: String, key: String, referencePath: String, index: Int) {
            Thread {
                try {
                    val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent")
                    val conn = url.openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json")
                    conn.setRequestProperty("x-goog-api-key", key)
                    val parts = JSONArray().apply {
                        if (referencePath.isNotBlank()) {
                            val ref = File(referencePath.removePrefix("file://"))
                            if (ref.exists()) put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/png").put("data", Base64.encodeToString(ref.readBytes(), Base64.NO_WRAP))))
                        }
                        put(JSONObject().put("text", prompt))
                    }
                    val req = JSONObject().apply {
                        put("contents", JSONArray().put(JSONObject().put("parts", parts)))
                        put("generationConfig", JSONObject().apply {
                            put("responseModalities", JSONArray().put("IMAGE"))
                            put("imageConfig", JSONObject().put("aspectRatio", "9:16").put("imageSize", "1K"))
                        })
                    }
                    conn.outputStream.use { it.write(req.toString().toByteArray()) }
                    val body = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
                    if (conn.responseCode !in 200..299) throw Exception(JSONObject(body).optJSONObject("error")?.optString("message") ?: "Erro ao gerar imagem")
                    val candidates = JSONObject(body).optJSONArray("candidates") ?: throw Exception("Gemini não retornou imagem")
                    var data: String? = null
                    var mime = "image/png"
                    for (i in 0 until candidates.length()) {
                        val p = candidates.getJSONObject(i).optJSONObject("content")?.optJSONArray("parts") ?: continue
                        for (j in 0 until p.length()) {
                            val part = p.getJSONObject(j)
                            val inline = part.optJSONObject("inlineData") ?: continue
                            data = inline.optString("data", null)
                            mime = inline.optString("mimeType", "image/png")
                            if (data != null) break
                        }
                        if (data != null) break
                    }
                    if (data == null) throw Exception("A geração de imagem não retornou dados")
                    val ext = if (mime.contains("jpeg")) "jpg" else "png"
                    val file = File(cacheDir, "scene_${index}_${System.currentTimeMillis()}.$ext")
                    file.writeBytes(Base64.decode(data, Base64.DEFAULT))
                    js("onNativeImageReady", JSONObject().put("index", index).put("path", Uri.fromFile(file).toString()).toString())
                } catch (e: Exception) { js("onNativeImageError", JSONObject().put("index", index).put("message", e.message ?: "Erro imagem").toString()) }
            }.start()
        }

        @JavascriptInterface
        fun beginVideoSave(name: String): String = try {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Cartoon V1")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: throw Exception("Não foi possível criar o arquivo")
            uri.toString()
        } catch (e: Exception) { "ERROR:${e.message ?: "erro"}" }

        @JavascriptInterface
        fun appendVideoChunk(b64: String): String = "ERROR: a versão MP4 não usa chunks WebM; use renderVideoNative()"

        @JavascriptInterface
        fun finishVideoSave(): String = "OK"

        @JavascriptInterface
        fun renderNativeVideo(framePathsJson: String, durationSec: Double, audioPath: String, fileName: String) {
            Thread {
                try {
                    val framePaths = JSONArray(framePathsJson)
                    val frames = ArrayList<android.graphics.Bitmap>()
                    for (i in 0 until framePaths.length()) {
                        val path = framePaths.getString(i).removePrefix("file://")
                        BitmapFactory.decodeFile(path)?.let { frames.add(it) } ?: throw Exception("Falha ao abrir cena ${i + 1}")
                    }
                    if (frames.isEmpty()) throw Exception("Nenhuma cena disponível")
                    val mp4 = encodeMp4(frames, durationSec, audioPath.removePrefix("file://"))
                    saveMp4ToGallery(mp4, fileName)
                    js("onNativeVideoReady", "OK")
                } catch (e: Exception) { js("onNativeVideoError", e.message ?: "Falha ao criar MP4") }
            }.start()
        }

        @JavascriptInterface
        fun deleteSavedKey() {
            getPreferences(MODE_PRIVATE).edit().remove("gemini_key_blob").apply()
        }

        @JavascriptInterface
        fun saveGeminiKey(key: String) {
            if (key.isBlank()) return deleteSavedKey()
            try {
                val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
                if (!ks.containsAlias("CartoonV1Key")) {
                    val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
                    kg.init(KeyGenParameterSpec.Builder("CartoonV1Key", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .build())
                    kg.generateKey()
                }
                val secret = ks.getKey("CartoonV1Key", null) as SecretKey
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.ENCRYPT_MODE, secret)
                val blob = ByteArrayOutputStream().apply {
                    write(cipher.iv.size); write(cipher.iv); write(cipher.doFinal(key.toByteArray(Charsets.UTF_8)))
                }.toByteArray()
                getPreferences(MODE_PRIVATE).edit().putString("gemini_key_blob", Base64.encodeToString(blob, Base64.NO_WRAP)).apply()
            } catch (_: Exception) {
                getPreferences(MODE_PRIVATE).edit().putString("gemini_key_blob", Base64.encodeToString(key.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)).apply()
            }
        }

        @JavascriptInterface
        fun getSavedGeminiKey(): String {
            val saved = getPreferences(MODE_PRIVATE).getString("gemini_key_blob", "") ?: return ""
            return try {
                val blob = Base64.decode(saved, Base64.DEFAULT)
                val ivLen = blob[0].toInt() and 255
                val iv = blob.copyOfRange(1, 1 + ivLen)
                val enc = blob.copyOfRange(1 + ivLen, blob.size)
                val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
                val secret = ks.getKey("CartoonV1Key", null) as SecretKey
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, secret, GCMParameterSpec(128, iv))
                String(cipher.doFinal(enc), Charsets.UTF_8)
            } catch (_: Exception) {
                try { String(Base64.decode(saved, Base64.DEFAULT), Charsets.UTF_8) } catch (_: Exception) { "" }
            }
        }

        private fun pcmToWav(pcm: ByteArray, rate: Int, channels: Int, bits: Int): ByteArray {
            val total = 36 + pcm.size
            val o = ByteArrayOutputStream(total + 8)
            fun le(v: Int) { o.write(v and 255); o.write((v shr 8) and 255); o.write((v shr 16) and 255); o.write((v shr 24) and 255) }
            o.write("RIFF".toByteArray()); le(total); o.write("WAVEfmt ".toByteArray()); le(16)
            o.write(byteArrayOf(1, 0)); o.write(byteArrayOf(channels.toByte(), 0)); le(rate); le(rate * channels * bits / 8)
            o.write(byteArrayOf((channels * bits / 8).toByte(), 0)); o.write(byteArrayOf(bits.toByte(), 0)); o.write("data".toByteArray()); le(pcm.size); o.write(pcm)
            return o.toByteArray()
        }

        private data class Sample(val data: ByteArray, val pts: Long, val flags: Int)

        private fun encodeMp4(bitmaps: List<android.graphics.Bitmap>, durationSec: Double, audioPath: String): File {
            val width = 720
            val height = 1280
            val fps = 30
            val frameCount = maxOf(1, (durationSec * fps).toInt())
            val videoSamples = encodeVideo(bitmaps, width, height, fps, frameCount)
            val audioSamples = encodeAudio(File(audioPath))
            val outFile = File(cacheDir, "CartoonV1_${System.currentTimeMillis()}.mp4")
            val mux = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val videoFormat = videoSamples.first.second
            val audioFormat = audioSamples.first.second
            val videoTrack = mux.addTrack(videoFormat)
            val audioTrack = mux.addTrack(audioFormat)
            mux.start()
            val vb = ByteBufferPool()
            for (s in videoSamples.first.first) mux.writeSampleData(videoTrack, vb.wrap(s.data), MediaCodec.BufferInfo().apply { size=s.data.size; presentationTimeUs=s.pts; flags=s.flags })
            for (s in audioSamples.first.first) mux.writeSampleData(audioTrack, vb.wrap(s.data), MediaCodec.BufferInfo().apply { size=s.data.size; presentationTimeUs=s.pts; flags=s.flags })
            mux.stop(); mux.release()
            return outFile
        }

        private class ByteBufferPool { fun wrap(data: ByteArray): java.nio.ByteBuffer = java.nio.ByteBuffer.wrap(data) }

        private fun encodeVideo(bitmaps: List<android.graphics.Bitmap>, width: Int, height: Int, fps: Int, frameCount: Int): Pair<List<Sample>, MediaFormat> {
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, 2_500_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = enc.createInputSurface()
            enc.start()
            val samples = ArrayList<Sample>()
            var outputFormat: MediaFormat? = null
            val info = MediaCodec.BufferInfo()
            val frameDurationMs = 1000L / fps
            try {
                for (i in 0 until frameCount) {
                    val canvas: Canvas = surface.lockCanvas(null)
                    canvas.drawColor(Color.BLACK)
                    val t = (i.toDouble() / maxOf(1, frameCount - 1)) * bitmaps.size
                    val idx = minOf(bitmaps.size - 1, t.toInt())
                    val local = t - idx
                    val bmp = bitmaps[idx]
                    val zoom = 1.0f + (local.toFloat() * 0.08f)
                    val panX = (((idx % 3) - 1) * 24f * local.toFloat())
                    val panY = (((idx % 2) == 0).let { if (it) -18f else 18f } * local.toFloat())
                    val scaledW = width * zoom
                    val scaledH = height * zoom
                    val left = (width - scaledW) / 2f + panX
                    val top = (height - scaledH) / 2f + panY
                    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                    paint.alpha = 255
                    canvas.drawBitmap(bmp, null, android.graphics.RectF(left, top, left + scaledW, top + scaledH), paint)
                    if (idx < bitmaps.size - 1 && local > 0.78) {
                        val next = bitmaps[idx + 1]
                        val fade = ((local - 0.78) / 0.22).toFloat().coerceIn(0f, 1f)
                        paint.alpha = (fade * 255).toInt()
                        canvas.drawBitmap(next, null, android.graphics.RectF(0f, 0f, width.toFloat(), height.toFloat()), paint)
                    }
                    surface.unlockCanvasAndPost(canvas)
                    Thread.sleep(frameDurationMs)
                    drainEncoder(enc, info, samples) { f -> if (outputFormat == null) outputFormat = f }
                }
                surface.release()
                enc.signalEndOfInputStream()
                var end = false
                while (!end) {
                    val out = enc.dequeueOutputBuffer(info, 10_000)
                    when {
                        out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> outputFormat = enc.outputFormat
                        out >= 0 -> {
                            if (info.size > 0) {
                                val b = enc.getOutputBuffer(out)!!; val data = ByteArray(info.size); b.position(info.offset); b.limit(info.offset + info.size); b.get(data); samples.add(Sample(data, info.presentationTimeUs, info.flags))
                            }
                            end = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                            enc.releaseOutputBuffer(out, false)
                        }
                    }
                }
            } finally { try { enc.stop() } catch (_: Exception) {}; enc.release() }
            return samples to (outputFormat ?: throw Exception("Formato de vídeo indisponível"))
        }

        private fun drainEncoder(enc: MediaCodec, info: MediaCodec.BufferInfo, samples: MutableList<Sample>, onFormat: (MediaFormat) -> Unit) {
            while (true) {
                val out = enc.dequeueOutputBuffer(info, 0)
                when {
                    out == MediaCodec.INFO_TRY_AGAIN_LATER -> return
                    out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormat(enc.outputFormat)
                    out >= 0 -> {
                        if (info.size > 0) {
                            val b = enc.getOutputBuffer(out)!!; val data = ByteArray(info.size); b.position(info.offset); b.limit(info.offset + info.size); b.get(data); samples.add(Sample(data, info.presentationTimeUs, info.flags))
                        }
                        enc.releaseOutputBuffer(out, false)
                    }
                }
            }
        }

        private fun encodeAudio(wav: File): Pair<List<Sample>, MediaFormat> {
            val bytes = wav.readBytes()
            val dataOffset = 44
            val pcm = bytes.copyOfRange(dataOffset, bytes.size)
            val sampleRate = 24000
            val channels = 1
            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 96000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); enc.start()
            val samples = ArrayList<Sample>(); var outFormat: MediaFormat? = null
            val info = MediaCodec.BufferInfo(); var pos = 0; val frame = 2048; var done = false
            while (!done) {
                val input = enc.dequeueInputBuffer(10_000)
                if (input >= 0) {
                    val b = enc.getInputBuffer(input)!!
                    b.clear(); val n = minOf(frame * 2, pcm.size - pos)
                    if (n > 0) { b.put(pcm, pos, n); val pts = (pos / 2L) * 1_000_000L / sampleRate; enc.queueInputBuffer(input, 0, n, pts, 0); pos += n }
                    else { enc.queueInputBuffer(input, 0, 0, (pcm.size / 2L) * 1_000_000L / sampleRate, MediaCodec.BUFFER_FLAG_END_OF_STREAM); done = true }
                }
                while (true) {
                    val out = enc.dequeueOutputBuffer(info, 0)
                    when {
                        out == MediaCodec.INFO_TRY_AGAIN_LATER -> break
                        out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> outFormat = enc.outputFormat
                        out >= 0 -> { if (info.size > 0) { val b=enc.getOutputBuffer(out)!!; val d=ByteArray(info.size); b.position(info.offset); b.limit(info.offset+info.size); b.get(d); samples.add(Sample(d,info.presentationTimeUs,info.flags)) }; enc.releaseOutputBuffer(out,false) }
                    }
                }
            }
            repeat(20) {
                val out=enc.dequeueOutputBuffer(info,1000)
                if(out>=0){if(info.size>0){val b=enc.getOutputBuffer(out)!!;val d=ByteArray(info.size);b.position(info.offset);b.limit(info.offset+info.size);b.get(d);samples.add(Sample(d,info.presentationTimeUs,info.flags))};val eos=info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM!=0;enc.releaseOutputBuffer(out,false);if(eos)return@repeat}
                else if(out==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED)outFormat=enc.outputFormat
            }
            try { enc.stop() } catch (_:Exception){}; enc.release()
            return samples to (outFormat ?: throw Exception("Formato de áudio indisponível"))
        }

        private fun saveMp4ToGallery(file: File, fileName: String) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, if (fileName.endsWith(".mp4")) fileName else "$fileName.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Cartoon V1")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: throw Exception("Não foi possível salvar o MP4")
            try {
                contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
                values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0); contentResolver.update(uri, values, null, null)
            } catch (e: Exception) { contentResolver.delete(uri, null, null); throw e }
        }
    }
}
