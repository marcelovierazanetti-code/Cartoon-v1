package com.cartoon.v4;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.*;
import android.net.Uri;
import androidx.core.content.FileProvider;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.*;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.json.*;

public class MainActivity extends Activity {
    private EditText tokenEdit, accountEdit, geminiEdit, storyEdit;
    private Button saveConfigBtn, generateBtn, previewBtn, downloadBtn, shareBtn;
    private TextureView videoPreview;
    private ExoPlayer previewPlayer;
    private Spinner durationSpinner, voiceSpinner, styleSpinner;
    private EditText channelNameEdit;
    private Button chooseLogoBtn;
    private Uri channelLogoUri;
    private Bitmap channelLogoBitmap;
    private int targetDurationSec=30;
    private TextView status;
    private ProgressBar progress;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private String lastVideoPath;
    private Uri lastSavedUri;

    private static final int W = 768;
    private static final int H = 1344;
    private static final int FPS = 24;
    private static final int SCENES = 6;
    private static final String[] DURATIONS = {"20 segundos • 3 imagens", "30 segundos • 6 imagens", "60 segundos • 10 imagens"};
    private static final int[] DURATION_VALUES = {20,30,60};
    private static final String[] VOICES = {"Kore • firme", "Charon • informativa", "Puck • animada", "Aoede • suave", "Orus • firme", "Leda • jovem", "Algenib • grave", "Achernar • suave", "Schedar • equilibrada", "Gacrux • adulta"};
    private static final String[] VOICE_IDS = {"Kore","Charon","Puck","Aoede","Orus","Leda","Algenib","Achernar","Schedar","Gacrux"};
    private static final String[] STYLES = {"Documentário", "Sombrio / mistério", "História / storytelling", "Aventura", "Emocionante", "Calmo / contemplativo", "Épico"};
    private static final int MIN_AUDIO_BYTES = 48000;
    private static final long MAX_AUDIO_MS = 90000L;
    private static final String CF_TEXT_MODEL = "@cf/meta/llama-3.1-8b-instruct-fast";
    private static final String CF_IMAGE_MODEL = "@cf/black-forest-labs/flux-2-klein-4b";
    private static final String CF_BASE = "https://api.cloudflare.com/client/v4/accounts/";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        loadConfig();
        loadBranding();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, float r) { GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r)); return g; }
    private TextView tv(String s, int sp) { TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp); t.setPadding(dp(2),dp(2),dp(2),dp(2)); return t; }

    private void buildUi() {
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(18),dp(18),dp(24));
        root.setBackgroundColor(Color.rgb(16,17,22));
        scroll.addView(root); setContentView(scroll);

        TextView title=tv("🎬 Cartoon V8.5.1",28); title.setTypeface(null,1); root.addView(title,new LinearLayout.LayoutParams(-1,dp(50)));
        TextView sub=tv("História → personagens → cenas → imagens → MP4 → narração → prévia → marca-d'água",15); sub.setTextColor(Color.rgb(170,172,184)); root.addView(sub,new LinearLayout.LayoutParams(-1,dp(40)));

        tokenEdit=field("Cloudflare API Token",true); root.addView(tokenEdit,new LinearLayout.LayoutParams(-1,dp(52)));
        accountEdit=field("Cloudflare Account ID",false); root.addView(accountEdit,new LinearLayout.LayoutParams(-1,dp(52)));
        geminiEdit=field("Gemini API Key (narração)",true); root.addView(geminiEdit,new LinearLayout.LayoutParams(-1,dp(52)));
        saveConfigBtn=button("🔐 Salvar configuração neste aparelho"); root.addView(saveConfigBtn); saveConfigBtn.setOnClickListener(v->{saveConfig(); saveBranding(); status("Configuração, voz, estilo e marca salvos neste aparelho.");});

        storyEdit=field("Ex.: Um menino encontra uma porta misteriosa em uma floresta...",false);
        storyEdit.setSingleLine(false); storyEdit.setGravity(Gravity.TOP); storyEdit.setPadding(dp(14),dp(14),dp(14),dp(14)); root.addView(storyEdit,new LinearLayout.LayoutParams(-1,dp(145)));

        root.addView(tv("⏱️ Duração do vídeo",14));
        durationSpinner=new Spinner(this); durationSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,DURATIONS)); root.addView(durationSpinner,new LinearLayout.LayoutParams(-1,dp(52)));
        durationSpinner.setSelection(1); durationSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){targetDurationSec=DURATION_VALUES[pos];} public void onNothingSelected(android.widget.AdapterView<?> p){}});

        root.addView(tv("🎙️ Voz da narração",14));
        voiceSpinner=new Spinner(this); voiceSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,VOICES)); root.addView(voiceSpinner,new LinearLayout.LayoutParams(-1,dp(52)));

        root.addView(tv("🎭 Estilo / tom da narração",14));
        styleSpinner=new Spinner(this); styleSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,STYLES)); root.addView(styleSpinner,new LinearLayout.LayoutParams(-1,dp(52)));

        channelNameEdit=field("Nome do canal (marca-d'água)",false); root.addView(channelNameEdit,new LinearLayout.LayoutParams(-1,dp(52)));
        chooseLogoBtn=button("🖼️ Escolher logo opcional"); root.addView(chooseLogoBtn); chooseLogoBtn.setOnClickListener(v->chooseChannelLogo());

        generateBtn=button("✨ Gerar história, cenas, imagens e vídeo"); root.addView(generateBtn); generateBtn.setOnClickListener(v->generate());
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setVisibility(ProgressBar.GONE); root.addView(progress,new LinearLayout.LayoutParams(-1,dp(8)));
        status=tv("Pronto.",14); status.setTextColor(Color.rgb(180,182,194)); status.setPadding(0,dp(12),0,dp(12)); root.addView(status);

        previewBtn=button("▶️ Ver vídeo antes de salvar"); previewBtn.setEnabled(false); root.addView(previewBtn); previewBtn.setOnClickListener(v->startPreview());

        videoPreview=new TextureView(this);
        videoPreview.setVisibility(View.GONE);
        videoPreview.setBackgroundColor(Color.BLACK);
        int contentWidthDp=(int)(getResources().getDisplayMetrics().widthPixels/getResources().getDisplayMetrics().density)-36;
        int previewHeightDp=Math.min(620,Math.max(360,(int)(contentWidthDp*16f/9f)));
        LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,dp(previewHeightDp));
        vp.setMargins(0,dp(8),0,dp(8));
        root.addView(videoPreview,vp);

        downloadBtn=button("💾 Salvar vídeo no celular"); downloadBtn.setEnabled(false); root.addView(downloadBtn); downloadBtn.setOnClickListener(v->saveVideoToGallery());
        shareBtn=button("📤 Compartilhar vídeo"); shareBtn.setEnabled(false); root.addView(shareBtn); shareBtn.setOnClickListener(v->shareVideo());

        TextView note=tv("V9.0 usa Cloudflare Workers AI para roteiro e imagens e Gemini 3.1 Flash TTS para narração com escolha de voz e estilo. A primeira cena vira referência de personagem e as cenas seguintes também usam a cena anterior. O vídeo é H.264/MP4 em 9:16, 24 FPS, com zoom, pan, transições e áudio AAC sincronizado.",13); note.setTextColor(Color.rgb(150,153,165)); note.setPadding(0,dp(18),0,0); root.addView(note);
    }

    private EditText field(String hint, boolean secret) {
        EditText e=new EditText(this); e.setHint(hint); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY); e.setSingleLine(!hint.startsWith("Ex.")); e.setBackground(bg(Color.rgb(27,29,37),14)); e.setPadding(dp(14),0,dp(14),0);
        if(secret) e.setInputType(129); return e;
    }
    private Button button(String s) { Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setAllCaps(false); b.setBackground(bg(Color.rgb(124,92,255),16)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52)); p.setMargins(0,dp(10),0,0); b.setLayoutParams(p); return b; }
    private void status(String s) { runOnUiThread(()->status.setText(s)); }
    private void setBusy(boolean x) { runOnUiThread(()->{ generateBtn.setEnabled(!x); saveConfigBtn.setEnabled(!x); progress.setVisibility(x?ProgressBar.VISIBLE:ProgressBar.GONE); }); }

    private void generate() {
        final String token=tokenEdit.getText().toString().trim();
        final String account=accountEdit.getText().toString().trim();
        final String geminiKey=geminiEdit.getText().toString().trim();
        final String idea=storyEdit.getText().toString().trim();
        if(token.isEmpty()){status("Cole seu Cloudflare API Token.");return;}
        if(account.isEmpty()){status("Cole seu Cloudflare Account ID.");return;}
        if(geminiKey.isEmpty()){status("Cole sua Gemini API Key para gerar a narração.");return;}
        if(idea.isEmpty()){status("Digite uma ideia para a história.");return;}
        saveConfig(); saveBranding(); setBusy(true); downloadBtn.setEnabled(false); shareBtn.setEnabled(false); previewBtn.setEnabled(false);
        lastVideoPath=null; lastSavedUri=null; stopPreview(); videoPreview.setVisibility(View.GONE);
        final int sceneCount=targetScenes(); final String selectedVoice=VOICE_IDS[Math.max(0,voiceSpinner.getSelectedItemPosition())]; final String selectedStyle=STYLES[Math.max(0,styleSpinner.getSelectedItemPosition())]; final String channelName=channelNameEdit.getText().toString().trim(); final Bitmap logoForVideo=channelLogoBitmap==null?null:channelLogoBitmap.copy(Bitmap.Config.ARGB_8888,true);
        executor.submit(()->{
            try {
                status("1/3 Criando roteiro e bíblia dos personagens...");
                JSONObject story=null;
                for(int storyAttempt=1; storyAttempt<=2; storyAttempt++){
                    story=new JSONObject(generateStory(account,token,idea,sceneCount));
                    JSONArray rawScenes=story.optJSONArray("scenes");
                    if(rawScenes!=null && rawScenes.length()==sceneCount) break;
                    if(storyAttempt<2) status("O roteiro veio com uma quantidade diferente de cenas; corrigindo e solicitando novamente...");
                }
                JSONArray scenes=normalizeScenes(story.getJSONArray("scenes"),sceneCount);
                String bible=story.optString("character_bible", "Keep the same characters, clothing, colors, face and proportions in every scene.");

                ArrayList<File> images=new ArrayList<>();
                byte[] characterRef=null, previousRef=null;
                for(int i=0;i<sceneCount;i++){
                    status("2/3 Gerando imagem "+(i+1)+"/"+sceneCount+" com FLUX.2 Klein...");
                    JSONObject sc=scenes.getJSONObject(i);
                    String mustShow=sc.optString("must_show","");
                    String mustAvoid=sc.optString("must_avoid","");
                    String prompt=bible+"\n\nSCENE "+(i+1)+": "+sc.getString("visual_prompt")+
                            "\n\nMUST SHOW EXACTLY: "+mustShow+"\nMUST AVOID: "+mustAvoid+
                            "\n\nSTRICT VISUAL CONTRACT: The scene specification is binding. Render every MUST SHOW item and every required action, location, important color and camera direction exactly as stated. Do not invent, replace, omit, merge, rename, age-change, gender-change, recolor, re-clothe, or reinterpret any named subject or object. Do not add characters, props, actions, locations, text, logos, subtitles, or story events that are not requested. Preserve exact identity from the master reference: face shape, hair, eyes, skin/fur, clothing, colors, accessories, body proportions and apparent age. The previous scene is continuity reference only; do not copy its composition when the current scene requests a different composition. Cinematic polished cartoon, rich environment detail, expressive faces, coherent lighting, vertical 9:16 composition. Family-friendly, fully clothed, no nudity, sexual content, bathing/changing clothes, blood or graphic injury. MUST AVOID items are forbidden. Do not substitute a different interpretation unless the safety fallback is explicitly activated.";
                    if(i==0) prompt += "\nThis first scene is the master character reference. Show the main character clearly, preferably full-body or three-quarter body, with face, hair, clothing and colors clearly visible.";
                    else prompt += "\nREFERENCE IMAGE 0 is the master character reference. REFERENCE IMAGE 1 is the previous scene. Preserve identity from the references while changing the setting, camera angle and action according to the scene.";
                    byte[] image=generateImage(account,token,prompt,characterRef,previousRef);
                    File f=new File(getCacheDir(),"cartoon_v9_scene_"+i+".jpg"); try(FileOutputStream out=new FileOutputStream(f)){out.write(image);} images.add(f);
                    if(i==0) characterRef=makeReference(image); previousRef=makeReference(image);
                }

                status("3/4 Gerando narração da história com Gemini TTS...");
                StringBuilder narration=new StringBuilder();
                for(int i=0;i<sceneCount;i++){
                    String n=scenes.getJSONObject(i).optString("narration","").trim();
                    if(!n.isEmpty()){ if(narration.length()>0)narration.append("\n\n"); narration.append(n); }
                }
                if(narration.length()==0) throw new IOException("A IA não retornou texto de narração.");
                byte[] pcm=generateGeminiTts(geminiKey,narration.toString(),selectedVoice,selectedStyle,targetDurationSec);
                if(pcm.length<MIN_AUDIO_BYTES) throw new IOException("O Gemini retornou uma narração vazia ou curta demais.");
                long rawAudioMs=(pcm.length/2L)*1000L/24000L;
                if(rawAudioMs>targetDurationSec*1000L+1500L) pcm=trimPcm(pcm,targetDurationSec*1000L);
                pcm=padPcmToDuration(pcm,targetDurationSec*1000L);
                long audioMs=(pcm.length/2L)*1000L/24000L;
                status("4/4 Montando MP4 H.264 + AAC com "+Math.round(audioMs/1000.0)+"s de narração...");
                File videoOnly=new File(getCacheDir(),"CartoonV8_5_2_video_"+System.currentTimeMillis()+".mp4");
                File video=new File(getCacheDir(),"CartoonV9_"+System.currentTimeMillis()+".mp4");
                int totalFrames=targetDurationSec*FPS;
                encodeVideo(images,videoOnly,totalFrames,channelName,logoForVideo);
                muxAudio(videoOnly,pcm,video,totalFrames);
                verifyVideo(video,totalFrames*1000L/FPS);
                lastVideoPath=video.getAbsolutePath();
                videoOnly.delete();
                runOnUiThread(()->{
                    previewBtn.setEnabled(true);
                    downloadBtn.setEnabled(true);
                    shareBtn.setEnabled(true);
                    videoPreview.setVisibility(View.VISIBLE);
                    startPreview();
                });
                status("Pronto! MP4 com narração Gemini, duração aproximada de "+Math.round((totalFrames/(double)FPS))+" segundos. Assista à prévia antes de salvar.");
            } catch(Exception e) { e.printStackTrace(); status("Erro: "+friendlyError(e)); }
            finally { setBusy(false); }
        });
    }

    /**
     * Normalizes occasional model deviations so one extra scene does not abort the whole render.
     * If the model returns more than six scenes, keep the first five and the final scene so the
     * opening character reference and the story ending are both preserved.
     */
    private int targetScenes(){ return targetDurationSec==20?3:(targetDurationSec==60?10:6); }

    private JSONArray normalizeScenes(JSONArray input,int count) throws Exception {
        if(input==null) throw new IOException("A IA não retornou a lista de cenas.");
        if(input.length()==count) return input;
        JSONArray out=new JSONArray();
        if(input.length()>count){
            for(int i=0;i<count-1;i++) out.put(input.getJSONObject(i));
            out.put(input.getJSONObject(input.length()-1));
            status("A IA retornou "+input.length()+" cenas; ajustando para "+count+" e preservando o final...");
            return out;
        }
        if(input.length()==0) throw new IOException("A IA não retornou nenhuma cena.");
        for(int i=0;i<input.length();i++) out.put(input.getJSONObject(i));
        JSONObject last=input.getJSONObject(input.length()-1);
        while(out.length()<count){
            JSONObject extra=new JSONObject();
            extra.put("narration", last.optString("narration", "A aventura continua...")+" E então, a história avança para um novo momento.");
            extra.put("visual_prompt", last.optString("visual_prompt", "The same characters continue the adventure in a new cinematic setting.")+" New continuation shot, different camera angle and environment details, same character identity.");
            extra.put("must_show", last.optString("must_show", "The established main character and the core story location."));
            extra.put("must_avoid", last.optString("must_avoid", "Any character, object or event not requested by the story."));
            out.put(extra);
        }
        status("A IA retornou "+input.length()+" cenas; completei automaticamente para "+count+".");
        return out;
    }

    private String friendlyError(Exception e) {
        String m=e.getMessage(); if(m==null)m=e.toString();
        if(m.contains("401")) return "Token Cloudflare inválido ou sem permissão Workers AI.";
        if(m.contains("403")) return "Cloudflare recusou a operação. Confira Workers AI - Read e Edit e o Account ID.";
        if(m.contains("429")) return "Limite da Cloudflare atingido. Aguarde o reset diário ou confira sua cota.";
        if(m.contains("Gemini HTTP 401")||m.contains("Gemini HTTP 403")) return "Gemini recusou a chave. Confira sua Gemini API Key.";
        if(m.contains("Gemini HTTP 429")) return "Limite do Gemini TTS atingido. Aguarde e tente novamente.";
        if(m.contains("JSON Mode")) return "A IA não conseguiu devolver o roteiro estruturado. Tente gerar novamente.";
        return m;
    }

    private String generateStory(String account,String token,String idea,int sceneCount)throws Exception {
        JSONObject schema=new JSONObject();
        schema.put("type","object");
        schema.put("properties",new JSONObject()
                .put("character_bible",new JSONObject().put("type","string"))
                .put("scenes",new JSONObject().put("type","array").put("items",new JSONObject().put("type","object")
                        .put("properties",new JSONObject().put("narration",new JSONObject().put("type","string")).put("visual_prompt",new JSONObject().put("type","string")).put("must_show",new JSONObject().put("type","string")).put("must_avoid",new JSONObject().put("type","string")))
                        .put("required",new JSONArray(Arrays.asList("narration","visual_prompt","must_show","must_avoid"))))));
        schema.getJSONObject("properties").getJSONObject("scenes").put("minItems",sceneCount).put("maxItems",sceneCount);
        schema.put("required",new JSONArray(Arrays.asList("character_bible","scenes")));

        String prompt="Create a short vertical cartoon video from this idea: "+idea+". IMPORTANT: return ONE JSON object containing EXACTLY "+sceneCount+" scenes in the scenes array — never fewer and never more. First write a precise character_bible describing every recurring character: age, apparent gender, body proportions, face, hair, eyes, skin/fur, clothing, colors, accessories and distinctive marks. Scene 1 must clearly establish the main character for later visual reference. Then write exactly "+sceneCount+" visually different scenes with narration, rich visual_prompt, must_show and must_avoid. For every scene, must_show must list the exact characters, objects, actions, location, important colors and composition that MUST visibly appear; must_avoid must list elements that must not appear. Do not invent visual details that contradict the story.  Preserve character identity across all scenes. Make scenes cinematic and varied: wide establishing, medium, close-up, action, emotional beat, final wide. Each narration must be concise, natural Portuguese and together all narrations should fit naturally into about "+Math.max(15,targetDurationSec-3)+" to "+(targetDurationSec-1)+" seconds of spoken narration. Do not put stage directions inside narration. Language: Portuguese.";
        JSONObject body=new JSONObject();
        body.put("messages",new JSONArray().put(new JSONObject().put("role","system").put("content","You are a professional storyboard writer for short vertical animated videos. Be precise and visual."))
                .put(new JSONObject().put("role","user").put("content",prompt)));
        body.put("max_tokens",3500); body.put("temperature",0.75);
        body.put("response_format",new JSONObject().put("type","json_schema").put("json_schema",schema));
        JSONObject res;
        try {
            res=cloudflareJson(account,token,CF_TEXT_MODEL,body);
        } catch(Exception first){
            String fm=first.getMessage()==null?"":first.getMessage();
            if(!fm.contains("JSON Mode") && !fm.toLowerCase(Locale.US).contains("json schema")) throw first;
            JSONObject fallbackBody=new JSONObject(body.toString());
            fallbackBody.remove("response_format");
            JSONArray msgs=fallbackBody.optJSONArray("messages");
            if(msgs!=null && msgs.length()>1){
                JSONObject user=msgs.getJSONObject(1);
                user.put("content",user.optString("content","")+" Return ONLY valid JSON with keys character_bible and scenes. Do not use markdown fences. The scenes array must contain exactly "+sceneCount+" objects.");
            }
            res=cloudflareJson(account,token,CF_TEXT_MODEL,fallbackBody);
        }
        Object response=null;
        JSONObject result=res.optJSONObject("result");
        if(result!=null) response=result.opt("response");
        if(response==null) response=res.opt("response");
        String text;
        if(response instanceof JSONObject || response instanceof JSONArray) text=response.toString();
        else text=response==null?"":String.valueOf(response);
        text=text.trim();
        if(text.startsWith("```")) text=text.replace("```json","").replace("```","").trim();
        if(text.isEmpty()) throw new IOException("A Cloudflare não retornou o roteiro.");
        return text;
    }

    private byte[] generateImage(String account,String token,String prompt,byte[] characterRef,byte[] previousRef)throws Exception {
        Exception last=null;
        String safePrompt=prompt;
        boolean safetyFallbackUsed=false;
        for(int attempt=0;attempt<4;attempt++){
            HttpURLConnection c=null;
            try {
                String url=CF_BASE+URLEncoder.encode(account,"UTF-8")+"/ai/run/"+CF_IMAGE_MODEL;
                String boundary="----CartoonV8_5"+System.nanoTime();
                c=(HttpURLConnection)new URL(url).openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(30000); c.setReadTimeout(180000); c.setDoOutput(true);
                c.setRequestProperty("Authorization","Bearer "+token);
                c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
                c.setRequestProperty("Accept","application/json");
                try(DataOutputStream out=new DataOutputStream(c.getOutputStream())){
                    multipartText(out,boundary,"prompt",safePrompt);
                    multipartText(out,boundary,"width","768");
                    multipartText(out,boundary,"height","1344");
                    multipartText(out,boundary,"guidance","5.0");
                    if(characterRef!=null)multipartFile(out,boundary,"input_image_0",characterRef,"reference_character.jpg","image/jpeg");
                    if(previousRef!=null)multipartFile(out,boundary,"input_image_1",previousRef,"reference_previous.jpg","image/jpeg");
                    out.writeBytes("--"+boundary+"--\r\n"); out.flush();
                }
                int code=c.getResponseCode();
                String body=read(code>=200&&code<300?c.getInputStream():c.getErrorStream());
                if(code>=200&&code<300){
                    JSONObject res=new JSONObject(body); JSONObject result=res.optJSONObject("result");
                    String b64=result==null?null:result.optString("image",null);
                    if(b64==null||b64.isEmpty())b64=res.optString("image",null);
                    if(b64==null||b64.isEmpty())throw new IOException("A Cloudflare não retornou a imagem.");
                    if(b64.startsWith("data:")){
                        int comma=b64.indexOf(',');
                        if(comma>=0)b64=b64.substring(comma+1);
                    }
                    byte[] decoded;
                    try{ decoded=android.util.Base64.decode(b64,android.util.Base64.DEFAULT); }
                    catch(IllegalArgumentException badBase64){ throw new IOException("A Cloudflare retornou uma imagem em formato inválido.",badBase64); }
                    if(decoded.length<1024)throw new IOException("A imagem retornada pela Cloudflare é inválida ou vazia.");
                    return decoded;
                }
                last=new IOException("Cloudflare imagem HTTP "+code+": "+body);
                if(code==400 && body.contains("3030") && !safetyFallbackUsed){
                    safetyFallbackUsed=true;
                    safePrompt=sanitizeForImageSafety(prompt);
                    characterRef=null;
                    previousRef=null;
                    status("A cena foi recusada pelo filtro da imagem; tentando uma versão neutra e familiar...");
                    continue;
                }
                if(code!=429 && code<500)throw last;
            }catch(Exception e){
                last=e;
                if(attempt==2)throw e;
            }finally{if(c!=null)c.disconnect();}
            Thread.sleep(1500L*(attempt+1));
        }
        throw last==null?new IOException("Falha ao gerar imagem."):last;
    }

    private String sanitizeForImageSafety(String prompt){
        return "FAMILY-FRIENDLY CARTOON SCENE. Reinterpret only the potentially sensitive part of the requested scene into a neutral, non-sensitive family setting. Keep the same story purpose, characters, clothing, age-appropriate appearance, colors and visual identity. No nudity, sexual content, bathing, changing clothes, bathroom/toilet focus, blood or graphic injury. Use a cinematic vertical composition with rich environment details.\n\nREQUESTED SCENE:\n"+prompt;
    }

    private void multipartText(DataOutputStream out,String b,String name,String value)throws Exception {
        out.writeBytes("--"+b+"\r\nContent-Disposition: form-data; name=\""+name+"\"\r\n\r\n"); out.write(value.getBytes("UTF-8")); out.writeBytes("\r\n");
    }
    private void multipartFile(DataOutputStream out,String b,String name,byte[] data,String filename,String mime)throws Exception {
        out.writeBytes("--"+b+"\r\nContent-Disposition: form-data; name=\""+name+"\"; filename=\""+filename+"\"\r\nContent-Type: "+mime+"\r\n\r\n"); out.write(data); out.writeBytes("\r\n");
    }

    private JSONObject cloudflareJson(String account,String token,String model,JSONObject body)throws Exception {
        Exception last=null;
        for(int attempt=0;attempt<3;attempt++){
            HttpURLConnection c=null;
            try{
                String url=CF_BASE+URLEncoder.encode(account,"UTF-8")+"/ai/run/"+model;
                c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(30000); c.setReadTimeout(120000); c.setDoOutput(true);
                c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Accept","application/json");
                try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes("UTF-8"));}
                int code=c.getResponseCode(); String s=read(code>=200&&code<300?c.getInputStream():c.getErrorStream());
                if(code>=200&&code<300) return new JSONObject(s);
                last=new IOException("Cloudflare HTTP "+code+": "+s);
                if(code!=429 && code<500) throw last;
            }catch(Exception e){last=e;if(attempt==2)throw e;}finally{if(c!=null)c.disconnect();}
            Thread.sleep(1200L*(attempt+1));
        }
        throw last==null?new IOException("Falha na Cloudflare."):last;
    }

    private String read(InputStream in)throws Exception { if(in==null)return ""; StringBuilder b=new StringBuilder(); byte[] buf=new byte[8192]; int n; while((n=in.read(buf))!=-1)b.append(new String(buf,0,n,"UTF-8")); return b.toString(); }

    private byte[] makeReference(byte[] original)throws Exception {
        Bitmap src=BitmapFactory.decodeByteArray(original,0,original.length); if(src==null)throw new IOException("Imagem de referência inválida.");
        int size=448; Bitmap small=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888); Canvas canvas=new Canvas(small); canvas.drawColor(Color.rgb(24,24,28));
        float scale=Math.min(size/(float)src.getWidth(),size/(float)src.getHeight()); float dw=src.getWidth()*scale, dh=src.getHeight()*scale;
        float left=(size-dw)*0.5f, top=(size-dh)*0.5f; canvas.drawBitmap(src,null,new RectF(left,top,left+dw,top+dh),new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));
        ByteArrayOutputStream out=new ByteArrayOutputStream(); small.compress(Bitmap.CompressFormat.JPEG,84,out);
        src.recycle(); small.recycle(); return out.toByteArray();
    }

    private byte[] generateGeminiTts(String apiKey,String text,String voice,String style,int durationSec)throws Exception {
        Exception last=null;
        String endpoint="https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-tts-preview:generateContent?key="+URLEncoder.encode(apiKey,"UTF-8");
        for(int attempt=0;attempt<3;attempt++){
            HttpURLConnection c=null;
            try{
                c=(HttpURLConnection)new URL(endpoint).openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(30000); c.setReadTimeout(180000); c.setDoOutput(true);
                c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Accept","application/json");
                JSONObject body=new JSONObject();
                body.put("contents",new JSONArray().put(new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text",
                        "Gere somente a narração falada da história abaixo, em português do Brasil. Estilo geral de interpretação: "+style+". Use uma voz de narrador natural, expressiva e adequada ao estilo escolhido, controlando ritmo, pausas, intensidade e emoção. Não leia instruções, títulos ou explicações; fale apenas a história. Texto:\n\n"+text)))));
                JSONObject gen=new JSONObject();
                gen.put("responseModalities",new JSONArray().put("AUDIO"));
                JSONObject prebuilt=new JSONObject().put("voiceName",voice);
                JSONObject voiceConfig=new JSONObject().put("prebuiltVoiceConfig",prebuilt);
                JSONObject speech=new JSONObject().put("voiceConfig",voiceConfig).put("languageCode","pt-BR");
                gen.put("speechConfig",speech); body.put("generationConfig",gen);
                try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes("UTF-8"));}
                int code=c.getResponseCode(); String response=read(code>=200&&code<300?c.getInputStream():c.getErrorStream());
                if(code>=200&&code<300){
                    JSONObject root=new JSONObject(response); JSONArray candidates=root.optJSONArray("candidates");
                    if(candidates==null||candidates.length()==0)throw new IOException("Gemini não retornou candidatos de áudio.");
                    JSONObject content=candidates.getJSONObject(0).optJSONObject("content");
                    JSONArray parts=content==null?null:content.optJSONArray("parts");
                    if(parts==null)throw new IOException("Gemini não retornou a faixa de áudio.");
                    for(int i=0;i<parts.length();i++){
                        JSONObject p=parts.getJSONObject(i); JSONObject inline=p.optJSONObject("inlineData");
                        if(inline==null)inline=p.optJSONObject("inline_data");
                        if(inline!=null){
                            String b64=inline.optString("data","");
                            if(!b64.isEmpty()){
                                byte[] pcm=android.util.Base64.decode(b64,android.util.Base64.DEFAULT);
                                if(pcm.length>=MIN_AUDIO_BYTES)return pcm;
                            }
                        }
                    }
                    throw new IOException("Gemini retornou uma resposta sem dados PCM de áudio.");
                }
                last=new IOException("Gemini HTTP "+code+": "+response);
                if(code!=429&&code<500)throw last;
            }catch(Exception e){last=e;if(attempt==2)throw e;}
            finally{if(c!=null)c.disconnect();}
            Thread.sleep(1500L*(attempt+1));
        }
        throw last==null?new IOException("Falha no Gemini TTS."):last;
    }

    private byte[] trimPcm(byte[] pcm,long maxMs){ int maxBytes=(int)Math.min(pcm.length,Math.max(2,(maxMs*24000L/1000L)*2L)); maxBytes-=maxBytes%2; return Arrays.copyOf(pcm,maxBytes); }
    private byte[] padPcmToDuration(byte[] pcm,long targetMs){ int targetBytes=(int)Math.min(Integer.MAX_VALUE,(targetMs*24000L/1000L)*2L); targetBytes-=targetBytes%2; if(pcm.length>=targetBytes)return Arrays.copyOf(pcm,targetBytes); return Arrays.copyOf(pcm,targetBytes); }

    private void muxAudio(File videoOnly,byte[] pcm,File output,int totalFrames)throws Exception {
        final int SAMPLE_RATE=24000, CHANNELS=1, BYTES_PER_SAMPLE=2;
        MediaExtractor extractor=new MediaExtractor(); extractor.setDataSource(videoOnly.getAbsolutePath());
        int videoTrack=-1;
        for(int i=0;i<extractor.getTrackCount();i++){
            MediaFormat f=extractor.getTrackFormat(i);
            if(f.getString(MediaFormat.KEY_MIME).startsWith("video/")){videoTrack=i;break;}
        }
        if(videoTrack<0)throw new IOException("Não encontrei a faixa de vídeo para adicionar a narração.");
        MediaFormat audioFormat=MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC,SAMPLE_RATE,CHANNELS);
        audioFormat.setInteger(MediaFormat.KEY_BIT_RATE,128000);
        audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE,MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        MediaCodec encoder=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        encoder.configure(audioFormat,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE); encoder.start();
        ArrayList<AudioSample> samples=new ArrayList<>(); MediaFormat encodedAudioFormat=null;
        int offset=0; boolean eos=false; long sampleIndex=0;
        try{
            while(!eos){
                int in=encoder.dequeueInputBuffer(10000);
                if(in>=0){
                    ByteBuffer ib=encoder.getInputBuffer(in); if(ib==null)throw new IOException("Buffer de áudio indisponível.");
                    ib.clear(); int remaining=pcm.length-offset; int n=Math.min(ib.remaining(),Math.max(0,remaining));
                    n-=n%BYTES_PER_SAMPLE;
                    if(n>0){ib.put(pcm,offset,n); long pts=(sampleIndex*1000000L)/SAMPLE_RATE; sampleIndex+=n/BYTES_PER_SAMPLE; offset+=n; encoder.queueInputBuffer(in,0,n,pts,0);}
                    else {long pts=(sampleIndex*1000000L)/(SAMPLE_RATE*CHANNELS); encoder.queueInputBuffer(in,0,0,pts,MediaCodec.BUFFER_FLAG_END_OF_STREAM); eos=true;}
                }
                while(true){
                    MediaCodec.BufferInfo info=new MediaCodec.BufferInfo(); int oi=encoder.dequeueOutputBuffer(info,0);
                    if(oi==MediaCodec.INFO_TRY_AGAIN_LATER)break;
                    if(oi==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){encodedAudioFormat=encoder.getOutputFormat();continue;}
                    if(oi>=0){
                        ByteBuffer ob=encoder.getOutputBuffer(oi);
                        if(ob!=null&&info.size>0){ob.position(info.offset);ob.limit(info.offset+info.size);byte[] data=new byte[info.size];ob.get(data);samples.add(new AudioSample(data,info.presentationTimeUs,info.flags));}
                        boolean done=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0; encoder.releaseOutputBuffer(oi,false); if(done){eos=true;break;}
                    }
                }
            }
            // Drain any remaining output after EOS.
            boolean done=false; while(!done){
                MediaCodec.BufferInfo info=new MediaCodec.BufferInfo(); int oi=encoder.dequeueOutputBuffer(info,10000);
                if(oi==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){encodedAudioFormat=encoder.getOutputFormat();continue;}
                if(oi==MediaCodec.INFO_TRY_AGAIN_LATER)continue;
                if(oi>=0){ByteBuffer ob=encoder.getOutputBuffer(oi);if(ob!=null&&info.size>0){ob.position(info.offset);ob.limit(info.offset+info.size);byte[] data=new byte[info.size];ob.get(data);samples.add(new AudioSample(data,info.presentationTimeUs,info.flags));}done=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;encoder.releaseOutputBuffer(oi,false);}
            }
            if(encodedAudioFormat==null)throw new IOException("Encoder AAC não retornou formato.");
        }finally{try{encoder.stop();}catch(Exception ignored){} encoder.release();}

        MediaMuxer mux=new MediaMuxer(output.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        try{
            int vt=mux.addTrack(extractor.getTrackFormat(videoTrack)); int at=mux.addTrack(encodedAudioFormat); mux.start();
            extractor.selectTrack(videoTrack); int firstSampleSize=(int)Math.min(Integer.MAX_VALUE,Math.max(65536L,extractor.getSampleSize())); ByteBuffer buf=ByteBuffer.allocate(firstSampleSize); MediaCodec.BufferInfo vi=new MediaCodec.BufferInfo();
            while(true){long sampleSize=extractor.getSampleSize();if(sampleSize<0)break;if(sampleSize>buf.capacity())buf=ByteBuffer.allocate((int)Math.min(Integer.MAX_VALUE,sampleSize));int n=extractor.readSampleData(buf,0);if(n<0)break;vi.offset=0;vi.size=n;vi.presentationTimeUs=extractor.getSampleTime();vi.flags=extractor.getSampleFlags();mux.writeSampleData(vt,buf,vi);extractor.advance();buf.clear();}
            for(AudioSample a:samples){if((a.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)!=0)continue;ByteBuffer b=ByteBuffer.wrap(a.data);MediaCodec.BufferInfo ai=new MediaCodec.BufferInfo();ai.offset=0;ai.size=a.data.length;ai.presentationTimeUs=a.pts;ai.flags=a.flags;mux.writeSampleData(at,b,ai);}
        }finally{try{mux.stop();}catch(Exception ignored){}mux.release();extractor.release();}
    }

    private static class AudioSample { final byte[] data; final long pts; final int flags; AudioSample(byte[] d,long p,int f){data=d;pts=p;flags=f;} }

    private void encodeVideo(ArrayList<File> files,File out,int totalFrames,String channelName,Bitmap logo)throws Exception {
        if(files.isEmpty())throw new IOException("Nenhuma cena para montar o vídeo.");
        MediaFormat fmt=MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC,W,H);
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        fmt.setInteger(MediaFormat.KEY_BIT_RATE,4500000);
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE,FPS);
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,1);

        MediaCodec codec=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        MediaMuxer mux=null; Surface surface=null;
        ArrayList<Bitmap> bitmaps=new ArrayList<>();
        formatReady=false; pendingTrack=-1;
        MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
        try{
            codec.configure(fmt,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);
            surface=codec.createInputSurface();
            codec.start();
            mux=new MediaMuxer(out.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            for(File f:files){
                Bitmap b=BitmapFactory.decodeFile(f.getAbsolutePath());
                if(b==null)throw new IOException("Imagem inválida: "+f.getName());
                bitmaps.add(b);
            }

            long frameNs=1000000000L/FPS;
            long next=System.nanoTime();
            int baseFrames=totalFrames/bitmaps.size();
            int extraFrames=totalFrames%bitmaps.size();
            for(int s=0;s<bitmaps.size();s++){
                Bitmap cur=bitmaps.get(s), prev=s>0?bitmaps.get(s-1):null;
                int frames=baseFrames+(s<extraFrames?1:0);
                int transition=Math.min(FPS/2,frames);
                for(int f=0;f<frames;f++){
                    next+=frameNs;
                    waitUntil(next);
                    Canvas canvas=surface.lockCanvas(null);
                    try{
                        canvas.drawColor(Color.BLACK);
                        float t=f/(float)Math.max(1,frames-1);
                        float zoom=1.0f+0.10f*t;
                        float fx=0.5f+0.12f*(float)Math.sin(t*Math.PI);
                        drawCover(canvas,cur,zoom,fx,1f);
                        if(prev!=null&&f<transition){
                            float a=f/(float)Math.max(1,transition-1);
                            canvas.drawColor(Color.BLACK);
                            drawCover(canvas,prev,1.08f,0.5f,1f-a);
                            drawCover(canvas,cur,1.0f,0.5f,a);
                        }
                        drawWatermark(canvas,channelName,logo);
                    }finally{surface.unlockCanvasAndPost(canvas);}
                    drain(codec,mux,info);
                }
            }

            codec.signalEndOfInputStream();
            boolean done=false;
            while(!done){
                int oi=codec.dequeueOutputBuffer(info,10000);
                if(oi==MediaCodec.INFO_TRY_AGAIN_LATER)continue;
                if(oi==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                    if(formatReady)throw new IllegalStateException("Formato do encoder mudou duas vezes.");
                    pendingTrack=mux.addTrack(codec.getOutputFormat());
                    mux.start();
                    formatReady=true;
                }else if(oi>=0){
                    if(info.size>0&&formatReady)writeSample(codec,oi,info,mux,pendingTrack);
                    done=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                    codec.releaseOutputBuffer(oi,false);
                }
            }
            if(!formatReady)throw new IOException("O encoder não produziu uma faixa de vídeo válida.");
        }finally{
            for(Bitmap b:bitmaps)b.recycle();
            if(surface!=null)surface.release();
            try{codec.stop();}catch(Exception ignored){}
            codec.release();
            if(mux!=null){if(formatReady){try{mux.stop();}catch(Exception ignored){}}mux.release();}
        }
    }

    private boolean formatReady=false;
    private int pendingTrack=-1;
    private void drain(MediaCodec codec,MediaMuxer mux,MediaCodec.BufferInfo info)throws Exception{
        while(true){
            int oi=codec.dequeueOutputBuffer(info,0);
            if(oi==MediaCodec.INFO_TRY_AGAIN_LATER)return;
            if(oi==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                if(formatReady)throw new IllegalStateException("Formato do encoder mudou duas vezes.");
                pendingTrack=mux.addTrack(codec.getOutputFormat());
                mux.start();
                formatReady=true;
                continue;
            }
            if(oi>=0){
                if(info.size>0&&formatReady)writeSample(codec,oi,info,mux,pendingTrack);
                codec.releaseOutputBuffer(oi,false);
            }
        }
    }
    private void writeSample(MediaCodec codec,int index,MediaCodec.BufferInfo info,MediaMuxer mux,int track){
        ByteBuffer data=codec.getOutputBuffer(index);
        if(data==null)return;
        data.position(info.offset); data.limit(info.offset+info.size);
        mux.writeSampleData(track,data,info);
    }

    private void waitUntil(long targetNs)throws InterruptedException{while(true){long remaining=targetNs-System.nanoTime();if(remaining<=0)return;long ms=remaining/1000000L;if(ms>1)Thread.sleep(ms-1);else Thread.yield();}}
    private void drawWatermark(Canvas c,String name,Bitmap logo){
        if((name==null||name.trim().isEmpty())&&logo==null)return;
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG); p.setAlpha(190);
        float x=W-18f, y=24f;
        if(logo!=null){ float max=54f; float scale=Math.min(max/logo.getWidth(),max/logo.getHeight()); float w=logo.getWidth()*scale,h=logo.getHeight()*scale; x-=w; c.drawBitmap(logo,null,new RectF(x,y,x+w,y+h),p); x-=8f; }
        if(name!=null&&!name.trim().isEmpty()){ p.setTextSize(16f); p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD)); p.setShadowLayer(2f,1f,1f,Color.BLACK); float tw=p.measureText(name.trim()); c.drawText(name.trim(),x-tw,y+22f,p); p.clearShadowLayer(); }
    }

    private void drawCover(Canvas c,Bitmap b,float zoom,float fx,float alpha){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);p.setAlpha((int)(255*Math.max(0,Math.min(1,alpha))));float scale=Math.max(W/(float)b.getWidth(),H/(float)b.getHeight())*zoom;float dw=b.getWidth()*scale,dh=b.getHeight()*scale;float left=(W-dw)*fx,top=(H-dh)*0.5f;c.drawBitmap(b,null,new RectF(left,top,left+dw,top+dh),p);}

    private void verifyVideo(File video,long expectedMs)throws Exception {
        if(!video.isFile()||video.length()<4096)throw new IOException("O MP4 foi criado vazio ou incompleto.");
        MediaMetadataRetriever r=new MediaMetadataRetriever();
        try{
            r.setDataSource(video.getAbsolutePath());
            String d=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            String w=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
            String h=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            String hasAudio=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO);
            long ms=d==null?0:Long.parseLong(d);
            int width=w==null?0:Integer.parseInt(w), height=h==null?0:Integer.parseInt(h);
            if(ms<expectedMs*0.90 || ms>expectedMs*1.15)throw new IOException("MP4 ficou com duração inválida ("+ms+" ms; esperado ~"+expectedMs+" ms). Gere novamente.");
            if(width!=W||height!=H)throw new IOException("MP4 ficou com resolução inesperada ("+width+"x"+height+").");
            if(!"yes".equalsIgnoreCase(hasAudio))throw new IOException("O MP4 foi criado sem faixa de áudio AAC.");
        }finally{r.release();}
    }

    private void chooseChannelLogo(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,2001);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==2001&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){ try{ channelLogoUri=data.getData(); getContentResolver().takePersistableUriPermission(channelLogoUri,Intent.FLAG_GRANT_READ_URI_PERMISSION); try(InputStream in=getContentResolver().openInputStream(channelLogoUri)){ channelLogoBitmap=BitmapFactory.decodeStream(in); } saveBranding(); status("Logo selecionado. Ele será aplicado como marca-d'água no canto superior."); }catch(Exception e){status("Não consegui carregar a logo: "+e.getMessage());} } }

    private void startPreview(){
        if(lastVideoPath==null){status("Gere um vídeo primeiro.");return;}
        videoPreview.setVisibility(View.VISIBLE);
        stopPreview();
        try{
            previewPlayer=new ExoPlayer.Builder(this).build();
            previewPlayer.setVideoTextureView(videoPreview);
            Uri previewUri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",new File(lastVideoPath));
            previewPlayer.setMediaItem(MediaItem.fromUri(previewUri));
            previewPlayer.setRepeatMode(ExoPlayer.REPEAT_MODE_OFF);
            previewPlayer.addListener(new androidx.media3.common.Player.Listener(){
                @Override public void onPlaybackStateChanged(int state){
                    if(state==androidx.media3.common.Player.STATE_READY){ status("Prévia pronta. Assista ao vídeo antes de salvar."); previewPlayer.play(); }
                    else if(state==androidx.media3.common.Player.STATE_ENDED){ status("Prévia concluída. Você pode assistir novamente ou salvar o MP4."); }
                }
                @Override public void onPlayerError(androidx.media3.common.PlaybackException error){ status("Falha na prévia: "+error.getErrorCodeName()+". O MP4 continua disponível para salvar."); }
            });
            previewPlayer.prepare();
        }catch(Exception e){ status("Não foi possível abrir a prévia: "+e.getMessage()); stopPreview(); }
    }
    private void stopPreview(){
        if(videoPreview!=null) previewPlayer.clearVideoTextureView(videoPreview);
        if(previewPlayer!=null){try{previewPlayer.clearMediaItems();}catch(Exception ignored){} try{previewPlayer.stop();}catch(Exception ignored){}try{previewPlayer.release();}catch(Exception ignored){}previewPlayer=null;}
    }
    private void saveVideoToGallery(){
        if(lastVideoPath==null){status("Gere um vídeo primeiro.");return;}
        if(Build.VERSION.SDK_INT<29&&checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE")!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"},1001);
            status("Autorize o armazenamento e toque em Salvar novamente."); return;
        }
        Uri created=null;
        try{
            File src=new File(lastVideoPath);
            if(!src.isFile()||src.length()<1024)throw new IOException("O MP4 temporário não existe ou está vazio.");
            String name="CartoonV9_"+System.currentTimeMillis()+".mp4";
            if(Build.VERSION.SDK_INT>=29){
                ContentValues v=new ContentValues();
                v.put(MediaStore.Video.Media.DISPLAY_NAME,name);
                v.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");
                v.put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/CartoonV9");
                v.put(MediaStore.Video.Media.IS_PENDING,1);
                created=getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v);
                if(created==null)throw new IOException("Não foi possível criar o arquivo no armazenamento.");
                OutputStream o=getContentResolver().openOutputStream(created);
                if(o==null)throw new IOException("Não foi possível abrir o arquivo para gravação.");
                try(InputStream in=new FileInputStream(src); OutputStream out=o){copyStream(in,out);}
                ContentValues publish=new ContentValues(); publish.put(MediaStore.Video.Media.IS_PENDING,0);
                if(getContentResolver().update(created,publish,null,null)<=0)throw new IOException("Não foi possível publicar o vídeo na galeria.");
                lastSavedUri=created;
                status("Salvo em Filmes/CartoonV9. MP4 publicado corretamente.");
            }else{
                File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),"CartoonV9");
                if(!dir.exists()&&!dir.mkdirs())throw new IOException("Não foi possível criar a pasta Filmes/CartoonV9.");
                File dst=new File(dir,name); copy(src,dst);
                lastSavedUri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",dst);
                status("Salvo em Filmes/CartoonV9.");
            }
        }catch(Exception e){
            if(created!=null)try{getContentResolver().delete(created,null,null);}catch(Exception ignored){}
            status("Erro ao salvar: "+e.getMessage());
        }
    }
    private void copy(File a,File b)throws Exception{try(InputStream i=new FileInputStream(a);OutputStream o=new FileOutputStream(b)){copyStream(i,o);}}
    private void copyStream(InputStream i,OutputStream o)throws Exception{byte[] z=new byte[8192];int n;while((n=i.read(z))!=-1)o.write(z,0,n);o.flush();}
    private void shareVideo(){
        if(lastSavedUri==null){status("Primeiro salve o vídeo no celular.");return;}
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("video/mp4"); i.putExtra(Intent.EXTRA_STREAM,lastSavedUri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try{startActivity(Intent.createChooser(i,"Compartilhar vídeo"));}catch(Exception e){status("Não foi possível abrir o compartilhamento: "+e.getMessage());}
    }

    private void saveBranding(){ try{ getPreferences(0).edit().putInt("duration",targetDurationSec).putInt("voice",voiceSpinner==null?0:voiceSpinner.getSelectedItemPosition()).putInt("style",styleSpinner==null?0:styleSpinner.getSelectedItemPosition()).putString("channel_name",channelNameEdit==null?"":channelNameEdit.getText().toString().trim()).apply(); if(channelLogoBitmap!=null){File f=new File(getFilesDir(),"channel_logo.png"); try(FileOutputStream o=new FileOutputStream(f)){channelLogoBitmap.compress(Bitmap.CompressFormat.PNG,100,o);}} }catch(Exception ignored){} }
    private void loadBranding(){ try{ targetDurationSec=getPreferences(0).getInt("duration",30); int di=targetDurationSec==20?0:(targetDurationSec==60?2:1); if(durationSpinner!=null)durationSpinner.setSelection(di); if(voiceSpinner!=null)voiceSpinner.setSelection(Math.min(getPreferences(0).getInt("voice",0),VOICE_IDS.length-1)); if(styleSpinner!=null)styleSpinner.setSelection(Math.min(getPreferences(0).getInt("style",0),STYLES.length-1)); if(channelNameEdit!=null)channelNameEdit.setText(getPreferences(0).getString("channel_name","")); File f=new File(getFilesDir(),"channel_logo.png"); if(f.isFile())channelLogoBitmap=BitmapFactory.decodeFile(f.getAbsolutePath()); }catch(Exception ignored){} }

    private void loadConfig(){try{String[] v=readSecrets();if(v[0]!=null)tokenEdit.setText(v[0]);if(v[1]!=null)accountEdit.setText(v[1]);if(v.length>2&&v[2]!=null)geminiEdit.setText(v[2]);}catch(Exception ignored){}}
    private void saveConfig(){try{writeSecrets(tokenEdit.getText().toString().trim(),accountEdit.getText().toString().trim(),geminiEdit.getText().toString().trim());}catch(Exception e){status("Não consegui salvar a configuração: "+e.getMessage());}}
    private SecretKey getSecretKey()throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias("cartoon_v4_key")){KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");kg.init(new KeyGenParameterSpec.Builder("cartoon_v4_key",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());kg.generateKey();}return ((KeyStore.SecretKeyEntry)ks.getEntry("cartoon_v4_key",null)).getSecretKey();}
    private void writeSecrets(String token,String account,String gemini)throws Exception{byte[] iv=new byte[12];new SecureRandom().nextBytes(iv);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,getSecretKey(),new GCMParameterSpec(128,iv));byte[] enc=c.doFinal((token+"\n"+account+"\n"+gemini).getBytes("UTF-8"));getPreferences(0).edit().putString("iv",android.util.Base64.encodeToString(iv,2)).putString("data",android.util.Base64.encodeToString(enc,2)).apply();}
    private String[] readSecrets()throws Exception{String ivs=getPreferences(0).getString("iv",null),ds=getPreferences(0).getString("data",null);if(ivs==null||ds==null)return new String[]{null,null,null};byte[] iv=android.util.Base64.decode(ivs,2),d=android.util.Base64.decode(ds,2);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,getSecretKey(),new GCMParameterSpec(128,iv));String s=new String(c.doFinal(d),"UTF-8");String[] parts=s.split("\n",-1);if(parts.length>=3)return new String[]{parts[0],parts[1],parts[2]};return new String[]{parts.length>0?parts[0]:"",parts.length>1?parts[1]:"",null};}
    @Override protected void onDestroy(){stopPreview();executor.shutdownNow();if(channelLogoBitmap!=null)channelLogoBitmap.recycle();super.onDestroy();}
}
