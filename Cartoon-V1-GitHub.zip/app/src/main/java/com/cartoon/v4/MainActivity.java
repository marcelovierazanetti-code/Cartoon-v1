package com.cartoon.v4;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.*;
import android.net.Uri;
import androidx.core.content.FileProvider;
import android.view.Gravity;
import android.view.Surface;
import android.widget.*;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.json.*;

public class MainActivity extends Activity {
    private EditText tokenEdit, accountEdit, storyEdit;
    private Button saveConfigBtn, generateBtn, downloadBtn, shareBtn;
    private TextView status;
    private ProgressBar progress;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private String lastVideoPath;
    private Uri lastSavedUri;

    private static final int W = 768;
    private static final int H = 1344;
    private static final int FPS = 24;
    private static final int SCENE_SEC = 4;
    private static final int SCENES = 6;
    private static final String CF_TEXT_MODEL = "@cf/meta/llama-3.1-8b-instruct-fast";
    private static final String CF_IMAGE_MODEL = "@cf/black-forest-labs/flux-2-klein-4b";
    private static final String CF_BASE = "https://api.cloudflare.com/client/v4/accounts/";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        loadConfig();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, float r) { GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r)); return g; }
    private TextView tv(String s, int sp) { TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp); t.setPadding(dp(2),dp(2),dp(2),dp(2)); return t; }

    private void buildUi() {
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(18),dp(18),dp(24));
        root.setBackgroundColor(Color.rgb(16,17,22));
        scroll.addView(root); setContentView(scroll);

        TextView title=tv("🎬 Cartoon V4",28); title.setTypeface(null,1); root.addView(title,new LinearLayout.LayoutParams(-1,dp(50)));
        TextView sub=tv("História → personagens → cenas → imagens → MP4 real",15); sub.setTextColor(Color.rgb(170,172,184)); root.addView(sub,new LinearLayout.LayoutParams(-1,dp(40)));

        tokenEdit=field("Cloudflare API Token",true); root.addView(tokenEdit,new LinearLayout.LayoutParams(-1,dp(52)));
        accountEdit=field("Cloudflare Account ID",false); root.addView(accountEdit,new LinearLayout.LayoutParams(-1,dp(52)));
        saveConfigBtn=button("🔐 Salvar configuração neste aparelho"); root.addView(saveConfigBtn); saveConfigBtn.setOnClickListener(v->{saveConfig(); status("Token e Account ID salvos com segurança neste aparelho.");});

        storyEdit=field("Ex.: Um menino encontra uma porta misteriosa em uma floresta...",false);
        storyEdit.setSingleLine(false); storyEdit.setGravity(Gravity.TOP); storyEdit.setPadding(dp(14),dp(14),dp(14),dp(14)); root.addView(storyEdit,new LinearLayout.LayoutParams(-1,dp(145)));

        generateBtn=button("✨ Gerar história, cenas, imagens e vídeo"); root.addView(generateBtn); generateBtn.setOnClickListener(v->generate());
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setVisibility(ProgressBar.GONE); root.addView(progress,new LinearLayout.LayoutParams(-1,dp(8)));
        status=tv("Pronto.",14); status.setTextColor(Color.rgb(180,182,194)); status.setPadding(0,dp(12),0,dp(12)); root.addView(status);

        downloadBtn=button("💾 Salvar vídeo no celular"); downloadBtn.setEnabled(false); root.addView(downloadBtn); downloadBtn.setOnClickListener(v->saveVideoToGallery());
        shareBtn=button("📤 Compartilhar vídeo"); shareBtn.setEnabled(false); root.addView(shareBtn); shareBtn.setOnClickListener(v->shareVideo());

        TextView note=tv("V4 usa Cloudflare Workers AI: Llama 3.1 8B Fast para roteiro estruturado e FLUX.2 Klein 4B para imagens. A primeira cena vira referência de personagem e as cenas seguintes também usam a cena anterior. O vídeo é H.264/MP4 em 9:16, 24 FPS, com zoom, pan e transições.",13); note.setTextColor(Color.rgb(150,153,165)); note.setPadding(0,dp(18),0,0); root.addView(note);
    }

    private EditText field(String hint, boolean secret) {
        EditText e=new EditText(this); e.setHint(hint); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY); e.setSingleLine(!hint.startsWith("Ex.")); e.setBackground(bg(Color.rgb(27,29,37),14)); e.setPadding(dp(14),0,dp(14),0);
        if(secret) e.setInputType(129); return e;
    }
    private Button button(String s) { Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setAllCaps(false); b.setBackground(bg(Color.rgb(124,92,255),16)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52)); p.setMargins(0,dp(10),0,0); b.setLayoutParams(p); return b; }
    private void status(String s) { runOnUiThread(()->status.setText(s)); }
    private void setBusy(boolean x) { runOnUiThread(()->{ generateBtn.setEnabled(!x); saveConfigBtn.setEnabled(!x); progress.setVisibility(x?ProgressBar.VISIBLE:ProgressBar.GONE); }); }

    private void generate() {
        final String token=tokenEdit.getText().toString().trim();
        final String account=accountEdit.getText().toString().trim();
        final String idea=storyEdit.getText().toString().trim();
        if(token.isEmpty()){status("Cole seu Cloudflare API Token.");return;}
        if(account.isEmpty()){status("Cole seu Cloudflare Account ID.");return;}
        if(idea.isEmpty()){status("Digite uma ideia para a história.");return;}
        saveConfig(); setBusy(true); downloadBtn.setEnabled(false); shareBtn.setEnabled(false); lastSavedUri=null;
        executor.submit(()->{
            try {
                status("1/3 Criando roteiro e bíblia dos personagens...");
                JSONObject story=new JSONObject(generateStory(account,token,idea));
                JSONArray scenes=story.getJSONArray("scenes");
                if(scenes.length()!=SCENES) throw new IOException("A IA retornou "+scenes.length()+" cenas. O V4 exige exatamente 6.");
                String bible=story.optString("character_bible", "Keep the same characters, clothing, colors, face and proportions in every scene.");

                ArrayList<File> images=new ArrayList<>();
                byte[] characterRef=null, previousRef=null;
                for(int i=0;i<SCENES;i++){
                    status("2/3 Gerando imagem "+(i+1)+"/"+SCENES+" com FLUX.2 Klein...");
                    JSONObject sc=scenes.getJSONObject(i);
                    String prompt=bible+"\n\nSCENE "+(i+1)+": "+sc.getString("visual_prompt")+
                            "\n\nVISUAL RULES: polished cinematic cartoon, rich environment, multiple visual details, expressive faces, coherent lighting, consistent character identity, same clothing and proportions, vertical composition, no text, no subtitles. Use different camera language per scene: wide establishing shot, medium shot, close-up, action/dynamic shot, emotional close-up, final cinematic wide shot. Make each scene visually distinct while preserving identity.";
                    if(i==0) prompt += "\nThis first scene is the master character reference. Show the main character clearly, preferably full-body or three-quarter body, with face, hair, clothing and colors clearly visible.";
                    else prompt += "\nREFERENCE IMAGE 0 is the master character reference. REFERENCE IMAGE 1 is the previous scene. Preserve identity from the references while changing the setting, camera angle and action according to the scene.";
                    byte[] image=generateImage(account,token,prompt,characterRef,previousRef);
                    File f=new File(getCacheDir(),"cartoon_v4_scene_"+i+".jpg"); try(FileOutputStream out=new FileOutputStream(f)){out.write(image);} images.add(f);
                    if(i==0) characterRef=makeReference(image); previousRef=makeReference(image);
                }

                status("3/3 Montando MP4 H.264 com duração real...");
                File video=new File(getCacheDir(),"CartoonV4_"+System.currentTimeMillis()+".mp4");
                encodeVideo(images,video);
                verifyVideo(video,SCENES*SCENE_SEC*1000L);
                lastVideoPath=video.getAbsolutePath();
                runOnUiThread(()->{downloadBtn.setEnabled(true);shareBtn.setEnabled(true);});
                status("Pronto! MP4 válido de aproximadamente "+(SCENES*SCENE_SEC)+" segundos. Toque em Salvar vídeo.");
            } catch(Exception e) { e.printStackTrace(); status("Erro: "+friendlyError(e)); }
            finally { setBusy(false); }
        });
    }

    private String friendlyError(Exception e) {
        String m=e.getMessage(); if(m==null)m=e.toString();
        if(m.contains("401")) return "Token Cloudflare inválido ou sem permissão Workers AI.";
        if(m.contains("403")) return "Cloudflare recusou a operação. Confira Workers AI - Read e Edit e o Account ID.";
        if(m.contains("429")) return "Limite da Cloudflare atingido. Aguarde o reset diário ou confira sua cota.";
        if(m.contains("JSON Mode")) return "A IA não conseguiu devolver o roteiro estruturado. Tente gerar novamente.";
        return m;
    }

    private String generateStory(String account,String token,String idea)throws Exception {
        JSONObject schema=new JSONObject();
        schema.put("type","object");
        schema.put("properties",new JSONObject()
                .put("character_bible",new JSONObject().put("type","string"))
                .put("scenes",new JSONObject().put("type","array").put("items",new JSONObject().put("type","object")
                        .put("properties",new JSONObject().put("narration",new JSONObject().put("type","string")).put("visual_prompt",new JSONObject().put("type","string")))
                        .put("required",new JSONArray(Arrays.asList("narration","visual_prompt"))))));
        schema.put("required",new JSONArray(Arrays.asList("character_bible","scenes")));

        String prompt="Create a short vertical cartoon video from this idea: "+idea+". Return exactly 6 scenes. First write a precise character_bible describing every recurring character: age, apparent gender, body proportions, face, hair, eyes, skin/fur, clothing, colors, accessories and distinctive marks. Scene 1 must clearly establish the main character for later visual reference. Then write six visually different scenes with narration and rich visual_prompt. Preserve character identity across all scenes. Make scenes cinematic and varied: wide establishing, medium, close-up, action, emotional beat, final wide. Language: Portuguese.";
        JSONObject body=new JSONObject();
        body.put("messages",new JSONArray().put(new JSONObject().put("role","system").put("content","You are a professional storyboard writer for short vertical animated videos. Be precise and visual."))
                .put(new JSONObject().put("role","user").put("content",prompt)));
        body.put("max_tokens",2200); body.put("temperature",0.75);
        body.put("response_format",new JSONObject().put("type","json_schema").put("json_schema",schema));
        JSONObject res=cloudflareJson(account,token,CF_TEXT_MODEL,body);
        JSONObject result=res.optJSONObject("result");
        String text=result==null?null:result.optString("response",null);
        if(text==null||text.trim().isEmpty()) text=res.optString("response","");
        if(text.trim().startsWith("```")) text=text.replace("```json","").replace("```","").trim();
        if(text.isEmpty()) throw new IOException("A Cloudflare não retornou o roteiro.");
        return text;
    }

    private byte[] generateImage(String account,String token,String prompt,byte[] characterRef,byte[] previousRef)throws Exception {
        Exception last=null;
        for(int attempt=0;attempt<3;attempt++){
            HttpURLConnection c=null;
            try {
                String url=CF_BASE+URLEncoder.encode(account,"UTF-8")+"/ai/run/"+CF_IMAGE_MODEL;
                String boundary="----CartoonV4"+System.nanoTime();
                c=(HttpURLConnection)new URL(url).openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(30000); c.setReadTimeout(180000); c.setDoOutput(true);
                c.setRequestProperty("Authorization","Bearer "+token);
                c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
                c.setRequestProperty("Accept","application/json");
                try(DataOutputStream out=new DataOutputStream(c.getOutputStream())){
                    multipartText(out,boundary,"prompt",prompt);
                    multipartText(out,boundary,"width","768");
                    multipartText(out,boundary,"height","1344");
                    if(characterRef!=null)multipartFile(out,boundary,"input_image_0",characterRef,"reference_character.jpg","image/jpeg");
                    if(previousRef!=null)multipartFile(out,boundary,"input_image_1",previousRef,"reference_previous.jpg","image/jpeg");
                    out.writeBytes("--"+boundary+"--\r\n"); out.flush();
                }
                int code=c.getResponseCode();
                String body=read(code>=200&&code<300?c.getInputStream():c.getErrorStream());
                if(code>=200&&code<300){
                    JSONObject res=new JSONObject(body); JSONObject result=res.optJSONObject("result");
                    String b64=result==null?null:result.optString("image",null);
                    if(b64==null||b64.isEmpty())b64=res.optString("image",null);
                    if(b64==null||b64.isEmpty())throw new IOException("A Cloudflare não retornou a imagem.");
                    byte[] decoded=android.util.Base64.decode(b64,android.util.Base64.DEFAULT);
                    if(decoded.length<1024)throw new IOException("A imagem retornada pela Cloudflare é inválida ou vazia.");
                    return decoded;
                }
                last=new IOException("Cloudflare imagem HTTP "+code+": "+body);
                if(code!=429 && code<500)throw last;
            }catch(Exception e){
                last=e;
                if(attempt==2)throw e;
            }finally{if(c!=null)c.disconnect();}
            Thread.sleep(1500L*(attempt+1));
        }
        throw last==null?new IOException("Falha ao gerar imagem."):last;
    }

    private void multipartText(DataOutputStream out,String b,String name,String value)throws Exception {
        out.writeBytes("--"+b+"\r\nContent-Disposition: form-data; name=\""+name+"\"\r\n\r\n"); out.write(value.getBytes("UTF-8")); out.writeBytes("\r\n");
    }
    private void multipartFile(DataOutputStream out,String b,String name,byte[] data,String filename,String mime)throws Exception {
        out.writeBytes("--"+b+"\r\nContent-Disposition: form-data; name=\""+name+"\"; filename=\""+filename+"\"\r\nContent-Type: "+mime+"\r\n\r\n"); out.write(data); out.writeBytes("\r\n");
    }

    private JSONObject cloudflareJson(String account,String token,String model,JSONObject body)throws Exception {
        Exception last=null;
        for(int attempt=0;attempt<3;attempt++){
            HttpURLConnection c=null;
            try{
                String url=CF_BASE+URLEncoder.encode(account,"UTF-8")+"/ai/run/"+model;
                c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(30000); c.setReadTimeout(120000); c.setDoOutput(true);
                c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Accept","application/json");
                try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes("UTF-8"));}
                int code=c.getResponseCode(); String s=read(code>=200&&code<300?c.getInputStream():c.getErrorStream());
                if(code>=200&&code<300) return new JSONObject(s);
                last=new IOException("Cloudflare HTTP "+code+": "+s);
                if(code!=429 && code<500) throw last;
            }catch(Exception e){last=e;if(attempt==2)throw e;}finally{if(c!=null)c.disconnect();}
            Thread.sleep(1200L*(attempt+1));
        }
        throw last==null?new IOException("Falha na Cloudflare."):last;
    }

    private String read(InputStream in)throws Exception { if(in==null)return ""; StringBuilder b=new StringBuilder(); byte[] buf=new byte[8192]; int n; while((n=in.read(buf))!=-1)b.append(new String(buf,0,n,"UTF-8")); return b.toString(); }

    private byte[] makeReference(byte[] original)throws Exception {
        Bitmap src=BitmapFactory.decodeByteArray(original,0,original.length); if(src==null)throw new IOException("Imagem de referência inválida.");
        int side=Math.min(src.getWidth(),src.getHeight()); int left=(src.getWidth()-side)/2; int top=(src.getHeight()-side)/2;
        Bitmap crop=Bitmap.createBitmap(src,left,top,side,side); Bitmap small=Bitmap.createScaledBitmap(crop,448,448,true); ByteArrayOutputStream out=new ByteArrayOutputStream(); small.compress(Bitmap.CompressFormat.JPEG,82,out);
        src.recycle(); crop.recycle(); small.recycle(); return out.toByteArray();
    }

    private void encodeVideo(ArrayList<File> files,File out)throws Exception {
        if(files.isEmpty())throw new IOException("Nenhuma cena para montar o vídeo.");
        MediaFormat fmt=MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC,W,H);
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        fmt.setInteger(MediaFormat.KEY_BIT_RATE,4500000);
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE,FPS);
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,1);

        MediaCodec codec=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        MediaMuxer mux=null; Surface surface=null;
        ArrayList<Bitmap> bitmaps=new ArrayList<>();
        formatReady=false; pendingTrack=-1;
        MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
        try{
            codec.configure(fmt,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);
            surface=codec.createInputSurface();
            codec.start();
            mux=new MediaMuxer(out.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            for(File f:files){
                Bitmap b=BitmapFactory.decodeFile(f.getAbsolutePath());
                if(b==null)throw new IOException("Imagem inválida: "+f.getName());
                bitmaps.add(b);
            }

            long frameNs=1000000000L/FPS;
            long next=System.nanoTime();
            for(int s=0;s<bitmaps.size();s++){
                Bitmap cur=bitmaps.get(s), prev=s>0?bitmaps.get(s-1):null;
                int frames=SCENE_SEC*FPS;
                int transition=Math.min(FPS/2,frames);
                for(int f=0;f<frames;f++){
                    next+=frameNs;
                    waitUntil(next);
                    Canvas canvas=surface.lockCanvas(null);
                    try{
                        canvas.drawColor(Color.BLACK);
                        float t=f/(float)Math.max(1,frames-1);
                        float zoom=1.0f+0.10f*t;
                        float fx=0.5f+0.12f*(float)Math.sin(t*Math.PI);
                        drawCover(canvas,cur,zoom,fx,1f);
                        if(prev!=null&&f<transition){
                            float a=f/(float)Math.max(1,transition-1);
                            canvas.drawColor(Color.BLACK);
                            drawCover(canvas,prev,1.08f,0.5f,1f-a);
                            drawCover(canvas,cur,1.0f,0.5f,a);
                        }
                    }finally{surface.unlockCanvasAndPost(canvas);}
                    drain(codec,mux,info);
                }
            }

            codec.signalEndOfInputStream();
            boolean done=false;
            while(!done){
                int oi=codec.dequeueOutputBuffer(info,10000);
                if(oi==MediaCodec.INFO_TRY_AGAIN_LATER)continue;
                if(oi==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                    if(formatReady)throw new IllegalStateException("Formato do encoder mudou duas vezes.");
                    pendingTrack=mux.addTrack(codec.getOutputFormat());
                    mux.start();
                    formatReady=true;
                }else if(oi>=0){
                    if(info.size>0&&formatReady)writeSample(codec,oi,info,mux,pendingTrack);
                    done=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                    codec.releaseOutputBuffer(oi,false);
                }
            }
            if(!formatReady)throw new IOException("O encoder não produziu uma faixa de vídeo válida.");
        }finally{
            for(Bitmap b:bitmaps)b.recycle();
            if(surface!=null)surface.release();
            try{codec.stop();}catch(Exception ignored){}
            codec.release();
            if(mux!=null){if(formatReady){try{mux.stop();}catch(Exception ignored){}}mux.release();}
        }
    }

    private boolean formatReady=false;
    private int pendingTrack=-1;
    private void drain(MediaCodec codec,MediaMuxer mux,MediaCodec.BufferInfo info)throws Exception{
        while(true){
            int oi=codec.dequeueOutputBuffer(info,0);
            if(oi==MediaCodec.INFO_TRY_AGAIN_LATER)return;
            if(oi==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                if(formatReady)throw new IllegalStateException("Formato do encoder mudou duas vezes.");
                pendingTrack=mux.addTrack(codec.getOutputFormat());
                mux.start();
                formatReady=true;
                continue;
            }
            if(oi>=0){
                if(info.size>0&&formatReady)writeSample(codec,oi,info,mux,pendingTrack);
                codec.releaseOutputBuffer(oi,false);
            }
        }
    }
    private void writeSample(MediaCodec codec,int index,MediaCodec.BufferInfo info,MediaMuxer mux,int track){
        ByteBuffer data=codec.getOutputBuffer(index);
        if(data==null)return;
        data.position(info.offset); data.limit(info.offset+info.size);
        mux.writeSampleData(track,data,info);
    }

    private void waitUntil(long targetNs)throws InterruptedException{while(true){long remaining=targetNs-System.nanoTime();if(remaining<=0)return;long ms=remaining/1000000L;if(ms>1)Thread.sleep(ms-1);else Thread.yield();}}
    private void drawCover(Canvas c,Bitmap b,float zoom,float fx,float alpha){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);p.setAlpha((int)(255*Math.max(0,Math.min(1,alpha))));float scale=Math.max(W/(float)b.getWidth(),H/(float)b.getHeight())*zoom;float dw=b.getWidth()*scale,dh=b.getHeight()*scale;float left=(W-dw)*fx,top=(H-dh)*0.5f;c.drawBitmap(b,null,new RectF(left,top,left+dw,top+dh),p);}

    private void verifyVideo(File video,long expectedMs)throws Exception {
        if(!video.isFile()||video.length()<4096)throw new IOException("O MP4 foi criado vazio ou incompleto.");
        MediaMetadataRetriever r=new MediaMetadataRetriever();
        try{
            r.setDataSource(video.getAbsolutePath());
            String d=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            String w=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
            String h=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            long ms=d==null?0:Long.parseLong(d);
            int width=w==null?0:Integer.parseInt(w), height=h==null?0:Integer.parseInt(h);
            if(ms<expectedMs*0.90)throw new IOException("MP4 ficou com duração inválida ("+ms+" ms). Gere novamente.");
            if(width!=W||height!=H)throw new IOException("MP4 ficou com resolução inesperada ("+width+"x"+height+").");
        }finally{r.release();}
    }

    private void saveVideoToGallery(){
        if(lastVideoPath==null){status("Gere um vídeo primeiro.");return;}
        if(Build.VERSION.SDK_INT<29&&checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE")!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"},1001);
            status("Autorize o armazenamento e toque em Salvar novamente."); return;
        }
        Uri created=null;
        try{
            File src=new File(lastVideoPath);
            if(!src.isFile()||src.length()<1024)throw new IOException("O MP4 temporário não existe ou está vazio.");
            String name="CartoonV4_"+System.currentTimeMillis()+".mp4";
            if(Build.VERSION.SDK_INT>=29){
                ContentValues v=new ContentValues();
                v.put(MediaStore.Video.Media.DISPLAY_NAME,name);
                v.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");
                v.put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/CartoonV4");
                v.put(MediaStore.Video.Media.IS_PENDING,1);
                created=getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v);
                if(created==null)throw new IOException("Não foi possível criar o arquivo no armazenamento.");
                OutputStream o=getContentResolver().openOutputStream(created);
                if(o==null)throw new IOException("Não foi possível abrir o arquivo para gravação.");
                try(InputStream in=new FileInputStream(src); OutputStream out=o){copyStream(in,out);}
                ContentValues publish=new ContentValues(); publish.put(MediaStore.Video.Media.IS_PENDING,0);
                if(getContentResolver().update(created,publish,null,null)<=0)throw new IOException("Não foi possível publicar o vídeo na galeria.");
                lastSavedUri=created;
                status("Salvo em Filmes/CartoonV4. MP4 publicado corretamente.");
            }else{
                File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),"CartoonV4");
                if(!dir.exists()&&!dir.mkdirs())throw new IOException("Não foi possível criar a pasta Filmes/CartoonV4.");
                File dst=new File(dir,name); copy(src,dst);
                lastSavedUri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",dst);
                status("Salvo em Filmes/CartoonV4.");
            }
        }catch(Exception e){
            if(created!=null)try{getContentResolver().delete(created,null,null);}catch(Exception ignored){}
            status("Erro ao salvar: "+e.getMessage());
        }
    }
    private void copy(File a,File b)throws Exception{try(InputStream i=new FileInputStream(a);OutputStream o=new FileOutputStream(b)){copyStream(i,o);}}
    private void copyStream(InputStream i,OutputStream o)throws Exception{byte[] z=new byte[8192];int n;while((n=i.read(z))!=-1)o.write(z,0,n);o.flush();}
    private void shareVideo(){
        if(lastSavedUri==null){status("Primeiro salve o vídeo no celular.");return;}
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("video/mp4"); i.putExtra(Intent.EXTRA_STREAM,lastSavedUri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try{startActivity(Intent.createChooser(i,"Compartilhar vídeo"));}catch(Exception e){status("Não foi possível abrir o compartilhamento: "+e.getMessage());}
    }

    private void loadConfig(){try{String[] v=readSecrets();if(v[0]!=null)tokenEdit.setText(v[0]);if(v[1]!=null)accountEdit.setText(v[1]);}catch(Exception ignored){}}
    private void saveConfig(){try{writeSecrets(tokenEdit.getText().toString().trim(),accountEdit.getText().toString().trim());}catch(Exception e){status("Não consegui salvar a configuração: "+e.getMessage());}}
    private SecretKey getSecretKey()throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias("cartoon_v4_key")){KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");kg.init(new KeyGenParameterSpec.Builder("cartoon_v4_key",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());kg.generateKey();}return ((KeyStore.SecretKeyEntry)ks.getEntry("cartoon_v4_key",null)).getSecretKey();}
    private void writeSecrets(String token,String account)throws Exception{byte[] iv=new byte[12];new SecureRandom().nextBytes(iv);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,getSecretKey(),new GCMParameterSpec(128,iv));byte[] enc=c.doFinal((token+"\n"+account).getBytes("UTF-8"));getPreferences(0).edit().putString("iv",android.util.Base64.encodeToString(iv,2)).putString("data",android.util.Base64.encodeToString(enc,2)).apply();}
    private String[] readSecrets()throws Exception{String ivs=getPreferences(0).getString("iv",null),ds=getPreferences(0).getString("data",null);if(ivs==null||ds==null)return new String[]{null,null};byte[] iv=android.util.Base64.decode(ivs,2),d=android.util.Base64.decode(ds,2);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,getSecretKey(),new GCMParameterSpec(128,iv));String s=new String(c.doFinal(d),"UTF-8");int p=s.indexOf('\n');return new String[]{p<0?s:s.substring(0,p),p<0?"":s.substring(p+1)};}
    @Override protected void onDestroy(){executor.shutdownNow();super.onDestroy();}
}
