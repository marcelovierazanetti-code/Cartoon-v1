package com.cartoon.v3;

import android.app.*;
import android.os.*;
import android.provider.MediaStore;
import android.os.Environment;
import android.security.keystore.KeyProperties;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.*;
import java.security.*;
import android.security.keystore.KeyGenParameterSpec;
import java.util.*;
import java.util.concurrent.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import org.json.*;
import java.net.*;

public class MainActivity extends Activity {
    EditText keyEdit, storyEdit; Button generateBtn, saveKeyBtn, downloadBtn, shareBtn; TextView status; ProgressBar progress;
    LinearLayout root; String lastVideoPath=null; Uri lastSavedUri=null; ExecutorService executor=Executors.newSingleThreadExecutor();
    final int W=720,H=1280,FPS=24, SCENE_SEC=4;

    @Override public void onCreate(Bundle b){ super.onCreate(b); buildUi(); loadKey(); }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp); t.setPadding(dp(2),dp(2),dp(2),dp(2)); return t; }
    GradientDrawable bg(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r)); return g; }
    void buildUi(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(24)); root.setBackgroundColor(Color.rgb(16,17,22)); scroll.addView(root); setContentView(scroll);
        TextView title=tv("🎬 Cartoon V3",28); title.setTypeface(null,1); root.addView(title,new LinearLayout.LayoutParams(-1,dp(50)));
        TextView sub=tv("Histórias → cenas → imagens → vídeo MP4 real",15); sub.setTextColor(Color.rgb(170,172,184)); root.addView(sub,new LinearLayout.LayoutParams(-1,dp(36)));
        keyEdit=new EditText(this); keyEdit.setHint("Sua Gemini API Key"); keyEdit.setTextColor(Color.WHITE); keyEdit.setHintTextColor(Color.GRAY); keyEdit.setSingleLine(true); keyEdit.setInputType(129); keyEdit.setPadding(dp(14),0,dp(14),0); keyEdit.setBackground(bg(Color.rgb(27,29,37),14)); root.addView(keyEdit,new LinearLayout.LayoutParams(-1,dp(52)));
        saveKeyBtn=button("🔐 Salvar chave neste aparelho"); root.addView(saveKeyBtn); saveKeyBtn.setOnClickListener(v->{saveKey(); status("Chave salva localmente.");});
        storyEdit=new EditText(this); storyEdit.setHint("Ex.: Um menino encontra uma porta misteriosa em uma floresta..."); storyEdit.setTextColor(Color.WHITE); storyEdit.setHintTextColor(Color.GRAY); storyEdit.setGravity(Gravity.TOP); storyEdit.setPadding(dp(14),dp(14),dp(14),dp(14)); storyEdit.setBackground(bg(Color.rgb(27,29,37),14)); root.addView(storyEdit,new LinearLayout.LayoutParams(-1,dp(145)));
        generateBtn=button("✨ Gerar história, cenas, imagens e vídeo"); root.addView(generateBtn); generateBtn.setOnClickListener(v->generate());
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setVisibility(View.GONE); root.addView(progress,new LinearLayout.LayoutParams(-1,dp(8)));
        status=tv("Pronto.",14); status.setTextColor(Color.rgb(180,182,194)); status.setPadding(0,dp(12),0,dp(12)); root.addView(status);
        downloadBtn=button("💾 Salvar vídeo no celular"); downloadBtn.setEnabled(false); root.addView(downloadBtn); downloadBtn.setOnClickListener(v->saveVideoToGallery());
        shareBtn=button("📤 Compartilhar vídeo"); shareBtn.setEnabled(false); root.addView(shareBtn); shareBtn.setOnClickListener(v->shareVideo());
        TextView note=tv("V3 usa a API Interactions do Gemini para texto e Gemini 3.1 Flash Image para cenas. O MP4 é codificado com H.264 + MediaMuxer, com duração real e fechamento correto do arquivo.",13); note.setTextColor(Color.rgb(150,153,165)); note.setPadding(0,dp(18),0,0); root.addView(note);
    }
    Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setAllCaps(false); b.setBackground(bg(Color.rgb(124,92,255),16)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52)); p.setMargins(0,dp(10),0,0); b.setLayoutParams(p); return b; }
    void status(String s){runOnUiThread(()->status.setText(s));}
    void setBusy(boolean x){runOnUiThread(()->{generateBtn.setEnabled(!x); progress.setVisibility(x?View.VISIBLE:View.GONE);});}

    void generate(){
        final String key=keyEdit.getText().toString().trim(), idea=storyEdit.getText().toString().trim();
        if(key.isEmpty()){status("Digite sua Gemini API Key."); return;} if(idea.isEmpty()){status("Digite uma ideia para a história."); return;}
        saveKey(); setBusy(true); lastVideoPath=null; downloadBtn.setEnabled(false); shareBtn.setEnabled(false);
        executor.submit(()->{try{
            status("1/3 Criando roteiro e personagens..."); String json=generateStory(key,idea); JSONObject obj=new JSONObject(json); JSONArray scenes=obj.getJSONArray("scenes"); if(scenes.length()!=6) throw new IOException("O roteiro retornou "+scenes.length()+" cenas; eram necessárias 6."); String bible=obj.optString("character_bible", "Keep characters visually consistent across all scenes.");
            ArrayList<File> imgs=new ArrayList<>(); String prevB64=null;
            for(int i=0;i<scenes.length();i++){ status("2/3 Gerando imagem "+(i+1)+"/"+scenes.length()+"..."); JSONObject sc=scenes.getJSONObject(i); String prompt=bible+"\n\nSCENE: "+sc.getString("visual_prompt")+"\nSTYLE: polished cinematic cartoon, detailed environment, expressive characters, consistent clothing, face and proportions, vertical 9:16, no text, no subtitles."; byte[] bytes=generateImage(key,prompt,prevB64); File f=new File(getCacheDir(),"scene_"+i+".jpg"); try(FileOutputStream out=new FileOutputStream(f)){out.write(bytes);} imgs.add(f); prevB64=android.util.Base64.encodeToString(bytes,android.util.Base64.NO_WRAP); }
            status("3/3 Montando MP4 com duração real..."); File video=new File(getCacheDir(),"CartoonV3_"+System.currentTimeMillis()+".mp4"); encodeVideo(imgs,video); lastVideoPath=video.getAbsolutePath(); runOnUiThread(()->{downloadBtn.setEnabled(true);shareBtn.setEnabled(true);}); status("Pronto! Vídeo MP4 gerado: "+SCENE_SEC*scenes.length()+"s. Toque em Salvar vídeo.");
        }catch(Exception e){ e.printStackTrace(); status("Erro: "+e.getMessage()); } finally{setBusy(false);} });
    }

    String generateStory(String key,String idea)throws Exception{
        JSONObject schema=new JSONObject(); schema.put("type","object"); JSONObject props=new JSONObject(); props.put("character_bible",new JSONObject().put("type","string")); JSONObject sceneSchema=new JSONObject(); sceneSchema.put("type","object"); sceneSchema.put("properties",new JSONObject().put("narration",new JSONObject().put("type","string")).put("visual_prompt",new JSONObject().put("type","string"))); sceneSchema.put("required",new JSONArray(Arrays.asList("narration","visual_prompt"))); props.put("scenes",new JSONObject().put("type","array").put("items",sceneSchema)); schema.put("properties",props); schema.put("required",new JSONArray(Arrays.asList("character_bible","scenes")));
        JSONObject body=new JSONObject(); body.put("model","gemini-3.6-flash"); body.put("input","Create a short vertical-video story from this idea: "+idea+". Return 6 scenes. Write a precise character bible first, then each scene with narration and a rich visual_prompt. Keep the same characters, clothing, colors, age and proportions in every scene. Make scenes visually different: wide shot, medium shot, close-up, action, emotional beat, final wide shot."); body.put("response_format",new JSONObject().put("type","text").put("mime_type","application/json").put("schema",schema)); body.put("generation_config",new JSONObject().put("thinking_level","low"));
        JSONObject res=post("https://generativelanguage.googleapis.com/v1beta/interactions",key,body); String text=extractText(res); if(text.startsWith("```")){text=text.replace("```json","").replace("```","").trim();} return text;
    }
    byte[] generateImage(String key,String prompt,String previousB64)throws Exception{
        JSONObject body=new JSONObject(); body.put("model","gemini-3.1-flash-image"); JSONArray input=new JSONArray(); if(previousB64!=null) input.put(new JSONObject().put("type","image").put("mime_type","image/jpeg").put("data",previousB64)); input.put(new JSONObject().put("type","text").put("text",prompt)); body.put("input",input); body.put("response_format",new JSONObject().put("type","image").put("mime_type","image/jpeg").put("aspect_ratio","9:16").put("image_size","1K")); JSONObject res=post("https://generativelanguage.googleapis.com/v1beta/interactions",key,body);
        JSONArray steps=res.optJSONArray("steps"); if(steps!=null) for(int i=steps.length()-1;i>=0;i--){JSONObject step=steps.getJSONObject(i); JSONArray c=step.optJSONArray("content"); if(c==null)continue; for(int j=c.length()-1;j>=0;j--){JSONObject block=c.getJSONObject(j); if("image".equals(block.optString("type"))){String d=block.optString("data",null); if(d!=null)return android.util.Base64.decode(d,android.util.Base64.DEFAULT);}}} throw new IOException("A API não retornou uma imagem. Verifique a chave, cota e modelo.");
    }
    JSONObject post(String url,String key,JSONObject body)throws Exception{
        Exception last=null;
        for(int attempt=0;attempt<3;attempt++){
            HttpURLConnection c=null;
            try{
                c=(HttpURLConnection)new URL(url).openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(30000); c.setReadTimeout(180000); c.setDoOutput(true);
                c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("x-goog-api-key",key);
                try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes("UTF-8"));}
                int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
                String s=read(in);
                if(code>=200&&code<300) return new JSONObject(s);
                last=new IOException("Gemini HTTP "+code+": "+s);
                if(code!=429 && code<500) throw last;
            }catch(Exception e){ last=e; if(attempt==2) throw e; } finally { if(c!=null) c.disconnect(); }
            Thread.sleep(1500L*(attempt+1));
        }
        throw last==null?new IOException("Falha na comunicação com o Gemini."):last;
    }
    String read(InputStream in)throws Exception{StringBuilder b=new StringBuilder(); byte[] buf=new byte[8192]; int n; while((n=in.read(buf))!=-1)b.append(new String(buf,0,n,"UTF-8")); return b.toString();}
    String extractText(JSONObject res){StringBuilder b=new StringBuilder(); JSONArray steps=res.optJSONArray("steps"); if(steps!=null)for(int i=0;i<steps.length();i++){JSONArray c=steps.optJSONObject(i).optJSONArray("content"); if(c!=null)for(int j=0;j<c.length();j++){JSONObject x=c.optJSONObject(j); if("text".equals(x.optString("type")))b.append(x.optString("text"));}} if(b.length()==0)b.append(res.optString("output_text","")); return b.toString();}

    void encodeVideo(ArrayList<File> files,File out)throws Exception{
        if(files.isEmpty()) throw new IOException("Nenhuma cena para montar o vídeo.");
        MediaFormat fmt=MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC,W,H);
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        fmt.setInteger(MediaFormat.KEY_BIT_RATE,3500000);
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE,FPS);
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,1);

        MediaCodec codec=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        MediaMuxer mux=null; Surface surface=null;
        ArrayList<Bitmap> bitmaps=new ArrayList<>();
        boolean muxStarted=false; int track=-1;
        MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
        try{
            codec.configure(fmt,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);
            surface=codec.createInputSurface();
            codec.start();
            mux=new MediaMuxer(out.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            for(File f:files){
                Bitmap b=BitmapFactory.decodeFile(f.getAbsolutePath());
                if(b==null) throw new IOException("Imagem inválida: "+f.getName());
                bitmaps.add(b);
            }

            final long frameNs=1000000000L/FPS;
            long nextFrameNs=System.nanoTime();
            for(int s=0;s<bitmaps.size();s++){
                Bitmap cur=bitmaps.get(s);
                Bitmap prev=s>0?bitmaps.get(s-1):null;
                int frames=SCENE_SEC*FPS;
                int transitionFrames=Math.min(FPS/2,frames);
                for(int f=0;f<frames;f++){
                    nextFrameNs += frameNs;
                    waitUntil(nextFrameNs);
                    Canvas canvas=surface.lockCanvas(null);
                    try{
                        canvas.drawColor(Color.BLACK);
                        float t=f/(float)Math.max(1,frames-1);
                        drawCover(canvas,cur,1.0f+0.08f*t,0.5f+0.10f*t,1f);
                        if(prev!=null && f<transitionFrames){
                            float a=f/(float)Math.max(1,transitionFrames-1);
                            canvas.drawColor(Color.BLACK);
                            drawCover(canvas,prev,1.08f,0.5f,1f-a);
                            drawCover(canvas,cur,1.0f,0.5f,a);
                        }
                    } finally {
                        surface.unlockCanvasAndPost(canvas);
                    }
                    while(true){
                        int oi=codec.dequeueOutputBuffer(info,0);
                        if(oi==MediaCodec.INFO_TRY_AGAIN_LATER) break;
                        if(oi==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                            if(muxStarted) throw new IllegalStateException("Formato do encoder mudou mais de uma vez.");
                            track=mux.addTrack(codec.getOutputFormat());
                            mux.start(); muxStarted=true;
                        }else if(oi>=0){
                            if(info.size>0 && muxStarted){
                                ByteBuffer data=codec.getOutputBuffer(oi);
                                if(data!=null){
                                    data.position(info.offset); data.limit(info.offset+info.size);
                                    mux.writeSampleData(track,data,info);
                                }
                            }
                            codec.releaseOutputBuffer(oi,false);
                        }
                    }
                }
            }

            codec.signalEndOfInputStream();
            boolean done=false;
            while(!done){
                int oi=codec.dequeueOutputBuffer(info,10000);
                if(oi==MediaCodec.INFO_TRY_AGAIN_LATER) continue;
                if(oi==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                    if(!muxStarted){
                        track=mux.addTrack(codec.getOutputFormat());
                        mux.start(); muxStarted=true;
                    }
                }else if(oi>=0){
                    if(info.size>0 && muxStarted){
                        ByteBuffer data=codec.getOutputBuffer(oi);
                        if(data!=null){
                            data.position(info.offset); data.limit(info.offset+info.size);
                            mux.writeSampleData(track,data,info);
                        }
                    }
                    done=(info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                    codec.releaseOutputBuffer(oi,false);
                }
            }
            if(!muxStarted) throw new IOException("O encoder não produziu uma faixa de vídeo válida.");
        } finally {
            for(Bitmap b:bitmaps) b.recycle();
            if(surface!=null) surface.release();
            try{codec.stop();}catch(Exception ignored){}
            codec.release();
            if(mux!=null){ if(muxStarted){try{mux.stop();}catch(Exception ignored){}} mux.release(); }
        }
    }

    void waitUntil(long targetNs)throws InterruptedException{
        while(true){
            long remaining=targetNs-System.nanoTime();
            if(remaining<=0) return;
            long ms=remaining/1000000L;
            int ns=(int)(remaining%1000000L);
            if(ms>1) Thread.sleep(ms-1); else if(ns>0) Thread.yield();
        }
    }

    void drawCover(Canvas c,Bitmap b,float zoom,float fx,float alpha){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG); p.setAlpha((int)(255*Math.max(0,Math.min(1,alpha)))); float scale=Math.max(W/(float)b.getWidth(),H/(float)b.getHeight())*zoom; float dw=b.getWidth()*scale,dh=b.getHeight()*scale; float left=(W-dw)*fx,top=(H-dh)*0.5f; c.drawBitmap(b,null,new RectF(left,top,left+dw,top+dh),p);}

    void saveVideoToGallery(){
        if(lastVideoPath==null){status("Gere um vídeo primeiro.");return;}
        if(Build.VERSION.SDK_INT<29 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE")!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"},1001);
            status("Autorize o armazenamento e toque em Salvar vídeo novamente.");
            return;
        }
        try{File src=new File(lastVideoPath); String name="CartoonV3_"+System.currentTimeMillis()+".mp4"; if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Video.Media.DISPLAY_NAME,name);v.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");v.put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/CartoonV3");v.put(MediaStore.Video.Media.IS_PENDING,1);Uri u=getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v);if(u==null)throw new IOException("Não foi possível criar o arquivo.");try(InputStream in=new FileInputStream(src);OutputStream o=getContentResolver().openOutputStream(u)){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)o.write(buf,0,n);}v.clear();v.put(MediaStore.Video.Media.IS_PENDING,0);getContentResolver().update(u,v,null,null);lastSavedUri=u;status("Salvo em Filmes/CartoonV3.");}else{File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),"CartoonV3");dir.mkdirs();File dst=new File(dir,name);copy(src,dst);status("Salvo em Filmes/CartoonV3. No Android antigo, abra a pasta Filmes/CartoonV3.");}}catch(Exception e){status("Erro ao salvar: "+e.getMessage());}}
    void copy(File a,File b)throws Exception{try(InputStream i=new FileInputStream(a);OutputStream o=new FileOutputStream(b)){byte[] z=new byte[8192];int n;while((n=i.read(z))!=-1)o.write(z,0,n);}}
    void shareVideo(){if(lastSavedUri==null){status("Primeiro toque em Salvar vídeo no celular.");return;} Intent i=new Intent(Intent.ACTION_SEND);i.setType("video/mp4");i.putExtra(Intent.EXTRA_STREAM,lastSavedUri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Compartilhar vídeo"));}

    void loadKey(){try{String x=readSecret();if(x!=null)keyEdit.setText(x);}catch(Exception ignored){}}
    void saveKey(){try{writeSecret(keyEdit.getText().toString().trim());}catch(Exception e){status("Não consegui salvar a chave: "+e.getMessage());}}
    SecretKey getSecretKey()throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias("cartoon_v3_key")){KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");kg.init(new KeyGenParameterSpec.Builder("cartoon_v3_key",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());kg.generateKey();}return ((KeyStore.SecretKeyEntry)ks.getEntry("cartoon_v3_key",null)).getSecretKey();}
    void writeSecret(String s)throws Exception{if(s.isEmpty())return;byte[] iv=new byte[12];new SecureRandom().nextBytes(iv);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,getSecretKey(),new GCMParameterSpec(128,iv));byte[] enc=c.doFinal(s.getBytes("UTF-8"));getPreferences(0).edit().putString("iv",android.util.Base64.encodeToString(iv,2)).putString("data",android.util.Base64.encodeToString(enc,2)).apply();}
    String readSecret()throws Exception{String ivs=getPreferences(0).getString("iv",null),ds=getPreferences(0).getString("data",null);if(ivs==null||ds==null)return null;byte[] iv=android.util.Base64.decode(ivs,2),d=android.util.Base64.decode(ds,2);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,getSecretKey(),new GCMParameterSpec(128,iv));return new String(c.doFinal(d),"UTF-8");}
    @Override protected void onDestroy(){executor.shutdownNow();super.onDestroy();}
}
