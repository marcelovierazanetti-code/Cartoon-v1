# Cartoon V3

Aplicativo Android para transformar uma ideia em uma história ilustrada vertical e montar um MP4 H.264.

## Build no GitHub Actions

O workflow `.github/workflows/build.yml` instala Java 17, Gradle 8.9 e Android SDK 35 e executa:

`gradle :app:assembleDebug --no-daemon --stacktrace`

O APK de debug é publicado como artefato `Cartoon-V3-APK`.

## Recursos

- Roteiro estruturado em 6 cenas com Gemini 3.6 Flash.
- Geração de imagens verticais 9:16 com Gemini 3.1 Flash Image.
- Referência da imagem anterior para melhorar a continuidade visual.
- Zoom/pan e crossfade entre cenas.
- MP4 H.264 via MediaCodec + MediaMuxer.
- Vídeo de 24 segundos (6 cenas x 4 s) em 24 FPS.
- Chave Gemini salva localmente e criptografada com Android Keystore.
- Salvamento em `Filmes/CartoonV3` usando MediaStore no Android 10+.
- Compartilhamento do vídeo salvo.
