# Cartoon V1

Primeira versão funcional do gerador de Shorts em estilo cartoon.

Fluxo: tema → roteiro Gemini → 5 cenas cartoon vetoriais → Gemini TTS → vídeo vertical WebM.
