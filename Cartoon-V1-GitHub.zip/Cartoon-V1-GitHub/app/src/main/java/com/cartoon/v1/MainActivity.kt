package com.cartoon.v1

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.ContentValues
import android.provider.MediaStore
import android.os.Environment
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var out: java.io.OutputStream? = null
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }
    inner class Bridge {
        @JavascriptInterface fun synthesizeGeminiNarration(text:String,key:String,voice:String,lang:String) {
            Thread {
                try {
                    val url=URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent")
                    val conn=url.openConnection() as HttpURLConnection
                    conn.requestMethod="POST"; conn.doOutput=true
                    conn.setRequestProperty("Content-Type","application/json")
                    conn.setRequestProperty("x-goog-api-key",key)
                    val req=JSONObject().apply {
                        put("contents", org.json.JSONArray().put(JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", text)))))
                        put("generationConfig", JSONObject().apply {
                            put("responseModalities", org.json.JSONArray().put("AUDIO"))
                            put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName",voice))))
                        })
                    }
                    conn.outputStream.use { it.write(req.toString().toByteArray()) }
                    val body=(if(conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
                    if(conn.responseCode !in 200..299) throw Exception(JSONObject(body).optJSONObject("error")?.optString("message") ?: "Erro Gemini TTS")
                    val inline=JSONObject(body).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData")
                    val b64=inline.getString("data")
                    val mime=inline.optString("mimeType","audio/L16;rate=24000")
                    val raw=Base64.decode(b64,Base64.DEFAULT)
                    val wav=pcmToWav(raw,24000,1,16)
                    val path="data:audio/wav;base64,"+Base64.encodeToString(wav,Base64.NO_WRAP)
                    web.post { web.evaluateJavascript("window.onNativeNarrationReady("+JSONObject.quote(path)+")",null) }
                } catch(e:Exception){ web.post { web.evaluateJavascript("window.onNativeError("+JSONObject.quote(e.message ?: "Erro TTS")+")",null) } }
            }.start()
        }
        private fun pcmToWav(pcm:ByteArray, rate:Int, channels:Int, bits:Int):ByteArray {
            val total=36+pcm.size; val o=ByteArrayOutputStream(total+8); fun le(v:Int){o.write(v and 255);o.write((v shr 8) and 255);o.write((v shr 16) and 255);o.write((v shr 24) and 255)}
            o.write("RIFF".toByteArray());le(total);o.write("WAVEfmt ".toByteArray());le(16);o.write(byteArrayOf(1,0));o.write(byteArrayOf(channels.toByte(),0));le(rate);le(rate*channels*bits/8);o.write(byteArrayOf((channels*bits/8).toByte(),0));o.write(byteArrayOf(bits.toByte(),0));o.write("data".toByteArray());le(pcm.size);o.write(pcm);return o.toByteArray()
        }
        @JavascriptInterface fun beginVideoSave(name:String):String { return try { val v=ContentValues().apply{put(MediaStore.Video.Media.DISPLAY_NAME,name);put(MediaStore.Video.Media.MIME_TYPE,"video/webm");put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/Cartoon V1");put(MediaStore.Video.Media.IS_PENDING,1)}; val uri=contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v)?:throw Exception("Não foi possível criar o arquivo"); out=contentResolver.openOutputStream(uri); uri.toString() } catch(e:Exception){"ERROR:"+(e.message?:"erro")} }
        @JavascriptInterface fun appendVideoChunk(b64:String):String=try{out?.write(Base64.decode(b64,Base64.DEFAULT));"OK"}catch(e:Exception){"ERROR:"+(e.message?:"erro")}
        @JavascriptInterface fun finishVideoSave():String=try{out?.close();out=null;"OK"}catch(e:Exception){"ERROR:"+(e.message?:"erro")}
        @JavascriptInterface fun cancelVideoSave():String {try{out?.close()}catch(_:Exception){};out=null;return "OK"}
    }
}
