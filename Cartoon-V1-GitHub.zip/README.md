# Cartoon V11.0

Pipeline robusto por cena: roteiro estruturado -> contrato cena/narração -> imagem FLUX.2 -> validação visual -> Gemini TTS por cena -> sincronização -> MP4.

- 20s: 3 cenas/imagens
- 30s: 6 cenas/imagens
- 60s: 10 cenas/imagens
- Gemini 3.1 Flash TTS, voz e estilo
- Prévia do MP4 real usando VideoView
- Nome/logo como marca-d’água
- H.264/AAC 9:16 24 FPS
- Continuidade por personagem + cena anterior
- Recuperação de bloqueio FLUX 3030 sem reenviar a mesma combinação
- Validação visual opcional com Gemini
- Configuração criptografada no Android Keystore
