# Cartoon V4

Aplicativo Android para transformar uma ideia em uma história vertical de 6 cenas, gerar imagens coerentes e montar um MP4 H.264 real.

## IA
- Cloudflare Workers AI REST API.
- Roteiro: `@cf/meta/llama-3.1-8b-instruct-fast` com JSON Mode.
- Imagens: `@cf/black-forest-labs/flux-2-klein-4b`.
- A primeira imagem é usada como referência mestre e a cena anterior é usada como referência de continuidade.
- O FLUX.2 Klein 4B aceita até 4 imagens de entrada; a V4 envia duas referências para as cenas seguintes.

## Vídeo
- 768x1344 (9:16), H.264/MP4, 24 FPS.
- 6 cenas de 4 segundos: aproximadamente 24 segundos.
- Zoom progressivo, pan e crossfade entre cenas.
- O MP4 é validado antes de liberar o salvamento, incluindo tamanho, duração e resolução.

## Credenciais
- Token Cloudflare e Account ID ficam armazenados localmente com Android Keystore + AES/GCM.
- O aplicativo não grava essas credenciais no código-fonte.

## Salvamento
- Android 10+: MediaStore com `IS_PENDING`, publicado somente depois que todos os bytes foram gravados.
- Android 9 e anteriores: `Filmes/CartoonV4`.
- Compartilhamento usa `content://` via FileProvider nos aparelhos antigos e MediaStore nos atuais.

## Build
- Java 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Android SDK 35
