# Cartoon V6.0

Aplicativo Android para criar vídeos verticais de histórias em 9:16.

## Fluxo
1. Roteiro estruturado em exatamente 6 cenas.
2. Bíblia de personagens para manter identidade visual.
3. Imagens FLUX.2 Klein 4B com referência da personagem e da cena anterior.
4. Fallback seguro quando uma cena é recusada pelo filtro de imagem (HTTP 400 / 3030).
5. Narração em português do Brasil com Gemini 3.1 Flash TTS, voz Kore.
6. MP4 H.264 + AAC com zoom, pan e transições.
7. Prévia dentro do app antes de salvar.
8. Salvar em Filmes/CartoonV6 e compartilhar.
9. Cloudflare Token, Account ID e Gemini Key armazenados criptografados no Android Keystore.

## V6.0 correções
- Corrigido cálculo de timestamps PCM/AAC para evitar áudio acelerado ou desalinhado.
- Se a IA devolver mais ou menos de 6 cenas, o app normaliza para 6 em vez de abortar.
- Se o JSON Schema da Cloudflare falhar, há uma segunda tentativa sem schema, exigindo JSON puro.
- Prévia sempre recarrega o MP4 recém-gerado e não reutiliza vídeo antigo.
- Referência visual preserva a composição inteira da primeira cena em vez de cortar o centro.
- Pasta de saída atualizada para CartoonV6.
- Mantido o mesmo applicationId do V5 para permitir atualização do aplicativo e preservar a configuração salva.
