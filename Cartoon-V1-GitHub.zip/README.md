# Cartoon V1 — atualização

Gerador de Shorts verticais com:

- roteiro Gemini em 5 cenas;
- bíblia de personagens para manter aparência/roupas coerentes;
- geração de imagens com `gemini-2.5-flash-image` em 9:16;
- primeira imagem usada como referência visual das cenas seguintes;
- narração Gemini TTS com Kore/Aoede/Charon/Puck;
- animação por zoom, panorâmica e crossfade entre cenas;
- renderização nativa Android para **MP4 H.264 + AAC**;
- salvamento em `Filmes/Cartoon V1`;
- chave Gemini salva localmente usando Android Keystore + AES/GCM;
- workflow GitHub Actions para gerar o APK.

## Fluxo

Tema → roteiro + character bible → 5 imagens IA → TTS → MP4 vertical → `Movies/Cartoon V1/`.

O MP4 é gerado nativamente pelo Android, em vez de apenas renomear um WebM, para evitar arquivos que plataformas de vídeo reconheçam com duração incorreta.
