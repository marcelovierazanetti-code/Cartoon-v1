# Cartoon V13.0

APK Android para criação de vídeos verticais a partir de uma ideia: roteiro estruturado → cenas → imagens → narração Gemini → MP4 H.264/AAC → prévia → salvar/compartilhar.

## V13.0
- Prévia interna reconstruída com `TextureView` + `MediaPlayer` + `Surface`, sem background drawable no TextureView.
- A prévia reproduz o mesmo MP4 final gerado pelo encoder.
- Liberação segura de MediaPlayer/Surface ao trocar de vídeo ou sair do app.
- Recuperação para bloqueios de imagem Cloudflare 3030 com alternativas progressivas.
- Verificação visual com rejeição apenas quando o avaliador retorna explicitamente `FAIL`.
- Em caso de resultado visual ambíguo após novas tentativas, o último frame gerado é usado para não travar o projeto inteiro.
- Duração: 20 s / 3 imagens, 30 s / 6 imagens, 60 s / 10 imagens.
- Voz e estilo de narração configuráveis.
- Nome e logo opcionais como marca-d'água.
- Android SDK 36, Java 17, AGP 8.10.1, Gradle 8.11.1.
