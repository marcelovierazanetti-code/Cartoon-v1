# Cartoon V7.0

Aplicativo Android para criar vídeos verticais de histórias em 9:16 com imagens, movimentos, transições e narração.

## O que há no V7
- Prévia real do MP4 dentro do app usando `TextureView + MediaPlayer`, em vez do `VideoView` que podia apresentar tela preta em alguns aparelhos.
- Três presets de duração: **20 s / 3 imagens**, **30 s / 6 imagens** e **60 s / 10 imagens**.
- Zoom, pan e transições mantidos em todas as durações.
- Narração Gemini 3.1 Flash TTS com escolha de voz.
- Estilos de narração: documentário, sombrio/mistério, história/storytelling, aventura, emocionante, calmo e épico. O Gemini TTS permite controlar estilo, tom e ritmo por instruções em linguagem natural.
- Nome do canal como marca-d'água no vídeo.
- Logo opcional escolhida pelo celular, também aplicada como marca-d'água.
- Nome, logo, duração, voz e estilo ficam salvos no aparelho.
- Chaves continuam protegidas pelo Android Keystore.
- Mantido FLUX.2 Klein 4B com referência da personagem e da cena anterior.
- Mantido fallback para recusas HTTP 3030 do gerador de imagens.
- MP4 H.264 + AAC em 9:16 / 24 FPS.
- Saída em `Filmes/CartoonV8.5`.

## Durações
| Preset | Cenas | Duração |
|---|---:|---:|
| Curto | 3 | 20 s |
| Padrão | 6 | 30 s |
| Longo | 10 | 60 s |

## Observação
O V7 usa o mesmo `applicationId` do aplicativo anterior (`com.cartoon.v4`) para permitir atualização sem criar outro app e preservar as configurações salvas.
