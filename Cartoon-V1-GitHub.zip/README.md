# Cartoon V5

App Android para gerar histórias verticais em 9:16 com cenas ilustradas, narração Gemini TTS, MP4 H.264/AAC e pré-visualização no próprio aplicativo antes do download.

## Fluxo
1. Roteiro estruturado em 6 cenas.
2. Imagens FLUX.2 Klein com referência de personagem e cena anterior.
3. Narração Gemini TTS com voz Kore.
4. MP4 H.264 + AAC.
5. Prévia do vídeo dentro do app.
6. Salvar no celular e compartilhar.
