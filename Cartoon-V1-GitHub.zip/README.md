# Cartoon V10.0

Pipeline por cena: roteiro estruturado -> contrato visual -> imagem -> narração TTS da mesma cena -> sincronização -> MP4.

- 20s: 3 cenas/imagens
- 30s: 6 cenas/imagens
- 60s: 10 cenas/imagens
- Voz e estilo do Gemini TTS
- Prévia usando VideoView do MP4 real antes de salvar
- Nome/logo como marca-d'água
- H.264/AAC 9:16 24 FPS
- Continuidade por referência de personagem + cena anterior
- Narração gerada separadamente por cena e encaixada na duração correspondente
